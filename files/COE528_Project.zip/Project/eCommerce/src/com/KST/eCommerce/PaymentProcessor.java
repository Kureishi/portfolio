package com.KST.eCommerce;
/**
 *
 * @author Kureishi Shivanand
 */
public class PaymentProcessor {
    // Overview: Prints message at the end of the session
    
    /**
     * Prints processing message
     *
     * @return String
     */
    public String processPayment() {
        // EFFECTS: Returns the message to indicate local session is ending
        
        return "Payment recieved.";
    }
}
