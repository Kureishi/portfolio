/* A simple echo client using TCP */
#include <stdio.h>
#include <netdb.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <stdlib.h>
#include <strings.h>
#include <string.h>
#include <fcntl.h>



#define SERVER_TCP_PORT 3000	/* well-known port */
#define BUFLEN		100	/* buffer length */

struct PDU{															// PDU structure defined
	char type;
	unsigned int length;
        char data[BUFLEN];
} rpdu,spdu;

int main(int argc, char **argv)
{
	int opt_select;
	int 	n, i, bytes_to_read, fd;
	int 	sd, port;
	struct	hostent		*hp;
	struct	sockaddr_in server;
	char	*host, *bp, rbuf[BUFLEN], sbuf[BUFLEN];
    struct PDU rpdu,spdu;											// an object for received PDU and sent PDU created

	switch(argc){													// based on how many strings typed in terminal
	case 2:
		host = argv[1];
		port = SERVER_TCP_PORT;
		break;
	case 3:
		host = argv[1];
		port = atoi(argv[2]);
		break;
	default:
		fprintf(stderr, "Usage: %s host [port]\n", argv[0]);		// the string typed in terminal is placed in the place holder
		exit(1);
	}

	/* Create a stream socket	*/	
	if ((sd = socket(AF_INET, SOCK_STREAM, 0)) == -1) {
		fprintf(stderr, "Can't create a socket\n");
		exit(1);
	}

	bzero((char *)&server, sizeof(struct sockaddr_in));				// place amount of 0s that are the size of socket address to server into the server address (make server address point to first address)
	server.sin_family = AF_INET;
	server.sin_port = htons(port);
	if (hp = gethostbyname(host)) 
	  bcopy(hp->h_addr, (char *)&server.sin_addr, hp->h_length);
	else if ( inet_aton(host, (struct in_addr *) &server.sin_addr) ){
	  fprintf(stderr, "Can't get server's address\n");
	  exit(1);
	}

	/* Connecting to the server */
	if (connect(sd, (struct sockaddr *)&server, sizeof(server)) == -1){
	  fprintf(stderr, "Can't connect \n");							// if receive standard error from terminal
	  exit(1);
	}
	
	printf("(1) Download a File\n, (2) Upload a File\n, (3) Change Current Directory\n, (4) List Files in Directory\n, (5) Exit\n");	// create user interface of menu options
	scanf("%d", &opt_select);										// the next value user types in get placed into opt_select
	while(1) {
		if(opt_select == 1) {										// for download from server
			printf("Enter file name for download: \n");
			n = read(0, spdu.data, BUFLEN);							// send input to sent PDU (the content inside)
 			spdu.type = 'D';										// D for download
			spdu.length = n;										// length of the PDU

			write(sd, &spdu, sizeof(spdu));							// write content in sent PDU to socket descriptor
			
			printf("File contents: \n");							// Pre-descriptor before file contents displayed
			while((n = read(sd, &rpdu, sizeof(rpdu))) != 0) {		// keep reading in what was in socket descriptor (sent PDU contents) until finished 
				rpdu.data[rpdu.length - 1] = '\0';					// append null character to make it into a string
				
				write(1, rpdu.data, rpdu.length);					// write the data from received PDU to the standard output
			}
		} else if (opt_select == 2) {								// for upload to server
  		  	printf("Enter file to be uploaded\n");
  			n = read(0, spdu.data, BUFLEN);							// read the value user typed in (from terminal) to sent PDU 
   			spdu.type = 'U';										// U for upload
  			spdu.length = n;										// length of the PDU

  			write(sd, &spdu, sizeof(spdu));							// write content in sent PDU to socket descriptor
  			spdu.data[spdu.length - 1] = '\0';						// append null character to make it into a string
  			n= read(sd, &rpdu, sizeof(rpdu));						// read what was in socket descriptor (sent PDU contents) into received PDU
  			if(rpdu.type ='R'){										// indicate server is ready for file to be uploaded (the PDU type sent by the server)
	  			printf("Uploaded\n");								// signify data uploaded
	  			fd = open(spdu.data, O_RDONLY);						// if data from sent PDU exists (can open)
		
		      		if(fd >= 0) {									// if exists
		      			spdu.type = 'F';							// indicates that the sent PDU contains file data
		      			while((n = read(fd, &spdu.data, BUFLEN)) != 0) {	// read from file descriptor (contains file data) into sent PDU until finished
		      				spdu.length = n;						// assign the length of the file (since PDU type = F)
		      				write(sd, &spdu, sizeof(spdu));			// write the contents of the sent PDU to the terminal
		      			}
		      		} else {										// if file to be uploaded not exists
					write(1, "Error: No such file\n", 22);			// print error to standard output
				}
  			}
		} else if (opt_select == 3) {
			printf("Enter directory: \n");							// for changing directories (from parent folder)
			n = read(0, spdu.data, BUFLEN);							// read from standard input into sent PDU data (returns number of bytes read)
			spdu.type = 'P';										// assign type as P to indicate changing directories
			spdu.length = n;										// assign the bytes read to the length
	
			write(sd, &spdu, sizeof(spdu));							// write the contents of sent PDU to the terminal

			n = read(sd, &rpdu, sizeof(rpdu));						// read what was in socket descriptor (sent PDU contents) 
  			if(rpdu.type = 'R') {									// indicate that server is ready to service request
				printf("Directory changed: \n");					// indicate directory changed
			}
		} else if (opt_select == 4) {								// for listing directories (from specific folder folder)
			printf("Enter directory \n");							
			n = read(0, spdu.data, BUFLEN);							// get from standard input into sent PDU data
			spdu.type = 'L';										// indicate listing files in directory
			spdu.length = n;										// assign the bytes read to the length
	
			write(sd, &spdu, sizeof(spdu));							// write the contents of sent PDU to the terminal

			n = read(sd, &rpdu, sizeof(rpdu));						// read what was in socket descriptor (sent PDU contents)
  			if(rpdu.type = 'l') {									// indicate that data field contains list of files (this PDU sent by server)
				printf("Files: \n");
				while((n = read(sd, &rpdu, sizeof(rpdu))) != 0) {	// keep reading in what was in socket descriptor (sent PDU contents) to receive PDU until finished 
					write(1, rpdu.data, rpdu.length);				// write the data from received PDU to the standard output
					printf("\n");
				}
			}
		} else if (opt_select == 5) {								// exit from service and return to main menu
			close(sd);												// close socket descriptor (since it's a file) 
			exit(0);
		}
		printf("(1) Download a File\n, (2) Upload a File\n, (3) Change Current Directory\n, (4) List Files in Directory\n, (5) Exit\n");	// create user interface of menu options
		scanf("%d", &opt_select);									// the next value user types in get placed into opt_select
		if ((sd = socket(AF_INET, SOCK_STREAM, 0)) == -1) {			// if error
			fprintf(stderr, "Can't create a socket\n");
			exit(1);
		}

		bzero((char *)&server, sizeof(struct sockaddr_in));		// place amount of 0s that are the size of socket address to server into the server address (make server address point to first address)
		server.sin_family = AF_INET;
		server.sin_port = htons(port);
		if (hp = gethostbyname(host)) 
		  bcopy(hp->h_addr, (char *)&server.sin_addr, hp->h_length);
		else if ( inet_aton(host, (struct in_addr *) &server.sin_addr) ){
		  fprintf(stderr, "Can't get server's address\n");
		  exit(1);
		}

		/* Connecting to the server */
		if (connect(sd, (struct sockaddr *)&server, sizeof(server)) == -1){
		  fprintf(stderr, "Cannot connect \n");
		  exit(1);
		}
	}
	close(sd);
	return(0);
}
