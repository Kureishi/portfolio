/* A simple echo server using TCP */
#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <sys/signal.h>
#include <sys/wait.h>
#include <stdlib.h>
#include <strings.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <dirent.h>

#define SERVER_TCP_PORT 3000	/* well-known port */
#define BUFLEN		256	/* buffer length */

struct PDU{
	char type;
	unsigned int length;
        char data[100];
} rpdu,spdu;

int echod(int);
void reaper(int);

int main(int argc, char **argv)
{
	int 	sd, new_sd, client_len, port;
	struct	sockaddr_in server, client;

	switch(argc){														// instantiating ports
	case 1:
		port = SERVER_TCP_PORT;
		break;
	case 2:
		port = atoi(argv[1]);
		break;
	default:
		fprintf(stderr, "Usage: %d [port]\n", argv[0]);
		exit(1);
	}

	/* Create a stream socket	*/	
	if ((sd = socket(AF_INET, SOCK_STREAM, 0)) == -1) {
		fprintf(stderr, "Can't create a socket\n");
		exit(1);
	}

	/* Bind an address to the socket	*/
	bzero((char *)&server, sizeof(struct sockaddr_in));
	server.sin_family = AF_INET;
	server.sin_port = htons(port);
	server.sin_addr.s_addr = htonl(INADDR_ANY);
	if (bind(sd, (struct sockaddr *)&server, sizeof(server)) == -1){
		fprintf(stderr, "Can't bind name to socket\n");
		exit(1);
	}

	/* queue up to 5 connect requests  */
	listen(sd, 5);	// since 5 options (including exit)

	(void) signal(SIGCHLD, reaper);

	while(1) {
	  client_len = sizeof(client);
	  new_sd = accept(sd, (struct sockaddr *)&client, &client_len);		// create a new file descriptor for client socket
	  if(new_sd < 0){													// if not successful
	    fprintf(stderr, "Can't accept client \n");
	    exit(1);
	  }
	  switch (fork()){													// used for listing files in directory
	  case 0:		/* child */
		(void) close(sd);
		exit(echod(new_sd));
	  default:		/* parent */
		(void) close(new_sd);
		break;
	  case -1:
		fprintf(stderr, "fork: error\n");
	  }
	}
}

/*	echoed program	*/
int echod(int sd)
{
	DIR *dir;															// DIR type indicate directory stream (since TCP uses stream of data transfer)
	struct dirent *ent;													// create structure (contains file serial number and name of entry)
	char cwd[1024];														// current working directory array (used for changing directories)
	char	*bp, buf[BUFLEN];
	int 	n, bytes_to_read, fd;
	struct PDU rpdu,spdu;
        
	n = read(sd, &rpdu, sizeof(rpdu));									// read what was in socket descriptor (sent PDU contents) into received PDU
	rpdu.data[rpdu.length - 1] = '\0';									// append null character to make it into a string
/*Type D PDU - Download request from the client*/
	if(rpdu.type == 'D') {												// if received PDU type is D (received from client) -> download service
		fd = open(rpdu.data, O_RDONLY);									// if data from received PDU exists (can open)
		
		if(fd >= 0) {													// if exists
			spdu.type = 'F';											// assign sent PDU (for client) as type F (indicate contain file data)
			while((n = read(fd, &spdu.data, BUFLEN)) != 0) {			// read from file descriptor (contains file data) into sent PDU until finished
				spdu.length = n;										// assign the length of the file (since PDU type = F)
				write(sd, &spdu, sizeof(spdu));							// write the contents of the sent PDU to the terminal
			}
		} else {
/*Type E PDU - Error Message*/
			spdu.type = 'E';											// indicates that server is reporting error to client (sent PDU)
			spdu.length = 22;											// length correspond to error message (string length)
			memcpy(spdu.data, "Error: File was not found\n", 22);		// copy message into data field of sent PDU (since type E)
			write(sd, &spdu, sizeof(spdu));								// write the contents of the sent PDU to the terminal
		}
/*Type U PDU - Upload request form the client*/
	} else if(rpdu.type == 'U'){										// if received PDU type is U -> upload service
	    spdu.type = 'R';												// indicate server is ready for file to be uploaded (the PDU type sent by the server)				
	    spdu.length = 0;												// just an indication (like a flag)
	    write(sd, &spdu, sizeof(spdu));									// write the contents of the sent PDU to the terminal
	    printf("Contents of file: \n");									// display the contents of the file
	    while((n = read(sd, &rpdu, sizeof(rpdu))) != 0) {				// keep reading in what was in socket descriptor (sent PDU contents) to receive PDU until finished
		rpdu.data[rpdu.length - 1] = '\0';								// append null character to make it into a string
		write(1, rpdu.data, rpdu.length);								// write the data from received PDU to the standard output
		printf("\n");
	    }
/*Type P PDU - Change directory request form the client*/
	} else if(rpdu.type == 'P') {										// if received PDU type is P -> change directories service
		chdir(rpdu.data);												// function used to change directory defined in data field of received PDU (from client)
	   	if (strcmp(getcwd(cwd, sizeof(cwd)), rpdu.data) == 0) {			// copy the data from received PDU into the current working directory (with the use of getcwd())
			printf("Current Directory: %s\n", cwd);						// print the current working directory
			spdu.type = 'R';											// indicates server ready to service
	    		spdu.length = 0;									    // just an indication (like a flag)
	    		write(sd, &spdu, sizeof(spdu));							// write the contents of the sent PDU to the terminal
		}
/*Type L PDU - List of files request.*/
	} else if(rpdu.type == 'L') {										// if received PDU type is L -> listing files in directory service
		if ((dir = opendir (rpdu.data)) != NULL) {						// opens the directory stream indicated by the received PDU (from client) data field
		  spdu.type = 'l';												// indicates data field contains list of file names
		  while ((ent = readdir (dir)) != NULL) {						// reads directory entry a current position of the directory stream from requested directory (keep reading files)
		  	memcpy(spdu.data, ent->d_name, strlen(ent->d_name) + 1);	// copy name of files into sent PDU data (to client)
			spdu.length = strlen(ent->d_name) + 1;						// the length of the name
			spdu.data[spdu.length - 1] = '\0';							// append null character to make it into a string
			write(sd, &spdu, sizeof(spdu));								// write the contents of the sent PDU to the terminal
		  }
		  closedir (dir);												// close the directory
		}
	}
	printf("\n");
	close(sd);															// close the socket descriptor
	return(0);
}

/*	reaper		*/
void	reaper(int sig)
{
	int	status;
	while(wait3(&status, WNOHANG, (struct rusage *)0) >= 0);
}
