package com.sachin.socialchatapp;

/***************************************************************************************************
 * IMPORTED LIBRARIES AND UTILITIES
 **************************************************************************************************/
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.IntentFilter;
import android.net.wifi.WifiManager;
import android.net.wifi.p2p.WifiP2pConfig;
import android.net.wifi.p2p.WifiP2pDevice;
import android.net.wifi.p2p.WifiP2pDeviceList;
import android.net.wifi.p2p.WifiP2pGroup;
import android.net.wifi.p2p.WifiP2pInfo;
import android.net.wifi.p2p.WifiP2pManager;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
/**************************************************************************************************/

public class MainActivity extends AppCompatActivity {

    Button btnOnOff, btnDiscover, btnSend;                          // Wifi enable/disable, discover nearby available peers, to send message
    ListView listView;                                              // available peers shown
    TextView read_msg_box, read_msg_box2, connectionStatus;         // received message shown, Connection Status shown
    EditText writeMsg;                                              // send message in EditText

    WifiManager wifiManager;                                        // object of WifiManager -> enable/disable WiFi
    WifiP2pManager mManager;                                        // objects used in BroadcastReceiver (manage WiFi peer-to-peer connectivity)
    WifiP2pManager.Channel mChannel;                                // channel connects application to WiFi P2P framework (most P2P operations require Channel as argument)

    BroadcastReceiver mReceiver;                                    // BroadcastReceiver object
    IntentFilter mIntentFilter;                                     // to use intents -> decipher which action is done

    List<WifiP2pDevice> peers = new ArrayList<WifiP2pDevice>();     // where peers appear
    String[] deviceNameArray;                                       // show device name (identifies device in WiFi Direct and Bluetooth) in list view
    WifiP2pDevice[] deviceArray;                                    // use array to connect a device

    static final int MESSAGE_READ = 1;                              // indicator of read message (since switch case take in int)

    ServerClass serverClass;                                        // create objects for three inner classes
    ClientClass clientClass;
    SendReceive sendReceive;

    String msgArray[] = new String[2];                              //message array used to store most recent 2 messages currently;
    int c =0;                                                       // Acts as a boolean
    boolean isConnected = false;
    boolean serverCreated = false;
    int portCount =0;
    int[]port = new int[2];
    boolean []portInUse = new boolean[2];



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        /*******************************************************************************************
         * INITIALIZATION OF VARIABLES
         ******************************************************************************************/

        btnOnOff = (Button)findViewById(R.id.onOff);                                                // Initialize variables to id-components
        btnDiscover = (Button)findViewById(R.id.discover);
        btnSend = (Button)findViewById(R.id.sendButton);

        listView = (ListView)findViewById(R.id.peerListView);

        read_msg_box = (TextView)findViewById(R.id.readMsg);
        read_msg_box2 = (TextView)findViewById(R.id.readMsg2);
        connectionStatus = (TextView)findViewById(R.id.connectionStatus);

        writeMsg = (EditText)findViewById(R.id.writeMsg);

        wifiManager = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE); // used for WiFi services

        mManager = (WifiP2pManager) getSystemService(Context.WIFI_P2P_SERVICE);                     // used for BroadcastReceiver
        mChannel = mManager.initialize(this, getMainLooper(), null);                // initialize P2P channel

        mReceiver = new WiFiDirectBroadcastReceiver(mManager, mChannel, this);              // initialize BroadcastReceiver constructor

        mIntentFilter = new IntentFilter();                                                         // initialize intent filter
        mIntentFilter.addAction(WifiP2pManager.WIFI_P2P_STATE_CHANGED_ACTION);                      // add intent actions to match against (when something happens)
        mIntentFilter.addAction(WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION);
        mIntentFilter.addAction(WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION);
        mIntentFilter.addAction(WifiP2pManager.WIFI_P2P_THIS_DEVICE_CHANGED_ACTION);

        msgArray[1] = "";                                                                           // initialize the message array
        msgArray[0] = "";

        port[0] = 1111;
        port[1] = 2222;

        portInUse[0] = false;
        portInUse[1] = false;

        exqListener();                                                                              // call exqListener (execute listener for buttons)
    }

    Handler handler = new Handler(new Handler.Callback() {                          // create object for handler (for read message) -> associate with Looper (run message loop for a thread) for current thread and take callback interface in which to handle messages
        @Override
        public boolean handleMessage(Message msg) {
            switch (msg.what) {                                                     // based on what action/intent/ what message is about
                case MESSAGE_READ:                                                  // since only read action used
                    byte[] readBuff = (byte[]) msg.obj;                             // send to recipient as stream of bytes
                    String tempMsg = new String(readBuff, 0, msg.arg1);       // read into first position of byte array (1st time)

                    if(c ==0){                                                      // ensures 1st time message is received
                        msgArray[0] = tempMsg;                                      // stored in index 0 of msgArray
                        c++;                                                        // increases integer so not iterate through this conditional branch again
                    }
                    else{
                        msgArray[1] = msgArray[0];                                  // stores previous message into index 1 of message array
                        msgArray[0] = tempMsg;                                      // overwrites old message location with new incoming message
                    }
                    read_msg_box.setText(msgArray[0]);                              // display in read message box on screen
                    read_msg_box2.setText((msgArray[1]));                           // display in second box (for older message)
                    break;
            }
            return true;                                                            // return true since it's a boolean method
        }
    });

    private void exqListener() {                                                    // execute listener methods (when buttons are clicked)
        btnOnOff.setOnClickListener(new View.OnClickListener() {                    // action for WiFi ON/OFF button
            @Override
            public void onClick(View view) {
                if(wifiManager.isWifiEnabled()) {                                   // check WiFi status (if WiFi is enabled)
                    wifiManager.setWifiEnabled(false);                              // if WiFi on, set it to false -> turn off (since already enabled)
                    btnOnOff.setText("ON");                                         // set text of button after WiFi off to indicate next button press turn "ON"
                }
                else {
                    wifiManager.setWifiEnabled(true);                               // if off, then enable it
                    btnOnOff.setText("OFF");                                        // set text of button after WiFi on to indicate next button press turn "OFF"
                }
            }
        });

        btnDiscover.setOnClickListener(new View.OnClickListener() {                     // action for "Discover" Button
            @Override
            public void onClick(View view) {
                mManager.discoverPeers(mChannel, new WifiP2pManager.ActionListener() {  // listen for when discovery process initiated (by other peers) -> application discovering neighboring peers ///ASIDE
                    @Override
                    public void onSuccess() {                                           // if discovered started successful
                        connectionStatus.setText("Discovery Started");                  // display text in "Connection Status" placeholder
                    }

                    @Override
                    public void onFailure(int i) {                                      // if discovered started unsuccessful
                        connectionStatus.setText("Discovery Starting Failed");          // display text in "Connection Status" placeholder
                    }
                });
            }
        });

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {         // action when an item pressed (in peerList)
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {     // initiate for clicking item in list

                final WifiP2pDevice device = deviceArray[i];                                    // for each device (peer-device) -> add in the array
                WifiP2pConfig config = new WifiP2pConfig();                                     // what WiFi property the device is configured/referenced with
                config.deviceAddress = device.deviceAddress;                                    // assign the config as the device (MAC -> unique identifier) address (connects with address)

                if(isConnected == false) { //Check if there is any connection already established

                    mManager.connect(mChannel, config, new WifiP2pManager.ActionListener() {        // the item clicked, is what would use to connect -> initialize connect (Wifi Direct channel, what link with -> address, and the listener define what to do) [start p2p connection to device with specified configuration -> MAC address]
                        @Override
                        public void onSuccess() {
                            Toast.makeText(getApplicationContext(), "Connected to " + device.deviceName, Toast.LENGTH_SHORT).show();    // when successful, display a toast indicating what device connected to
                            isConnected = true; //Set connection to true


                        }

                        @Override
                        public void onFailure(int i) {
                            Toast.makeText(getApplicationContext(), "Not Connected " + device.deviceName, Toast.LENGTH_SHORT).show();   // when fail, indicate the item failed to connect to
                        }
                    });

                }
                else { //Check if connection is already made
                    mManager.requestGroupInfo(mChannel, new WifiP2pManager.GroupInfoListener() {

                        @Override
                        public void onGroupInfoAvailable(WifiP2pGroup group) {
                            if (group != null && mManager != null && mChannel != null){
                                try {
                                    if(group.isGroupOwner()== true) {
                                        serverClass.serverSocket.close(); //Close server socket is node is Server
                                    }
                                    else
                                    clientClass.socket.close(); //Close client socket if node is client
                                }
                                catch(Exception e){
                                    Toast.makeText(getApplicationContext(), "Not Connected " + e, Toast.LENGTH_SHORT).show();
                                }
                                mManager.removeGroup(mChannel, new WifiP2pManager.ActionListener() { //Remove group connection list

                                    @Override
                                    public void onSuccess() {
                                        Toast.makeText(getApplicationContext(), "Disconnected from" + device.deviceName,
                                                Toast.LENGTH_SHORT).show();
                                        isConnected = false; //Change connection to false
                                    }

                                    @Override
                                    public void onFailure(int reason) {
                                        //Log.d(TAG, "removeGroup onFailure -" + reason);
                                        Toast.makeText(getApplicationContext(), "Failed to disconnect from:" + device.deviceName,
                                                Toast.LENGTH_SHORT).show();
                                    }
                                });
                            }
                        }
                    });

                }
            }
        });

        btnSend.setOnClickListener(new View.OnClickListener() {                                 // action for "send" button
            @Override
            public void onClick(View view) {
                String msg = login.uName + ": " + writeMsg.getText().toString();                // from write message box (username typed in login concatenate with message typed to send) -> from sending device
                sendReceive.write(msg.getBytes());                                              // write the String message in the terminal as an array of bytes
                writeMsg.setText("");                                                           // after type in writeMsg field, set to blank (clear text) for next time

                msgArray[1] = msgArray[0];                                                      // stores previous message into index 1 of message array
                msgArray[0] = msg;                                                              // overwrites old message location with new incoming message

                read_msg_box.setText(msgArray[0]);                                              // display in read message box on screen  -> similar to when reading messages
                read_msg_box2.setText(msgArray[1]);                                             // display in second box (for older message)

            }
        });
    }

    WifiP2pManager.PeerListListener peerListListener = new WifiP2pManager.PeerListListener() {      // how the peer devices (those with discovery on) in the listview are taken care of -> interface for callback invocation when peerList available -> after discoverPeers above
        @Override
        public void onPeersAvailable(WifiP2pDeviceList peerList) {                                  // inform whether peerList changed or not after receiving requested available peerList
            if(!peerList.getDeviceList().equals(peers)) {                                           // if current list not same as old list ("peers" holds device list of availble peers)
                peers.clear();                                                                      // clear old/previous list
                peers.addAll(peerList.getDeviceList());                                             // add the devices that is in peerList to the new/current list

                deviceNameArray = new String[peerList.getDeviceList().size()];                      // initialize deviceNameArray with size based on the amount of devices
                deviceArray = new WifiP2pDevice[peerList.getDeviceList().size()];                   // initialize deviceArray

                int index = 0;                                                                      // initialize counter/index at 0
                for (WifiP2pDevice device: peerList.getDeviceList()) {                              // iterations depend on number of devices in peerList (all devices)
                    deviceNameArray[index] = device.deviceName;                                     // get name of the device and place in array at index
                    deviceArray[index] = device;                                                    // get the device and place in array at index
                    index++;                                                                        // increase counter so place new position each time
                }

                ArrayAdapter<String> adapter = new ArrayAdapter<String>(getApplicationContext(),
                        android.R.layout.simple_list_item_1, deviceNameArray); // place deviceNameArray contents into "simple_list_item_1" ID for the listview in layout resource file (getApplicationContext -> content for entire application (process all activities running inside of))
                listView.setAdapter(adapter);                                                       // put the above list of devices in the listview formatted by the defined adapter
            }

            if(peers.size() == 0) {                                                                          // if no device found in list (0 devices)

                Toast.makeText(getApplicationContext(), "No Device Found", Toast.LENGTH_SHORT).show();  // display toast message indicating so
                return;                                                                                     // return nothing since void
            }
        }
    };


    WifiP2pManager.ConnectionInfoListener connectionInfoListener = new WifiP2pManager.ConnectionInfoListener() {    // interface for callback when connection info is available
        @Override
        public void onConnectionInfoAvailable(WifiP2pInfo wifiP2pInfo) {                                    // the connection info between devices (requested info is available)
            final InetAddress groupOwnerAddress = wifiP2pInfo.groupOwnerAddress;                            // owner's/host or server address
            Toast.makeText(getApplicationContext(), "ENTER CONNECTION LISTENER", Toast.LENGTH_SHORT).show();
            if (wifiP2pInfo.groupFormed && wifiP2pInfo.isGroupOwner) {       // if formed group/pair (indicates if a p2p group has been successfully formed) and also owner (name that was initially tapped from Client's device)
                connectionStatus.setText("Host");                           // indicate device is a server/host/group owner

                if(portCount ==0) {
                    //initiateServer(port[0]);
                    serverClass = new ServerClass();                            // instantiate object
                    serverClass.setPortNum(port[0]);
                    serverClass.start();                                        // start the Server Class
                    Toast.makeText(getApplicationContext(), "Server Port: " + serverClass.portNum +" Created ",
                            Toast.LENGTH_SHORT).show();
                    portCount ++;
                }
                else if(portCount ==1){
                    //initiateServer(port[1]);
                    serverClass = new ServerClass();                            // instantiate object
                    serverClass.setPortNum(port[1]);
                    serverClass.start();                                        // start the Server Class
                    Toast.makeText(getApplicationContext(), "Server Port: " + serverClass.portNum +" Created ",
                            Toast.LENGTH_SHORT).show();
                    portCount++;
                }
                else{
                    Toast.makeText(getApplicationContext(), "All ports are used", Toast.LENGTH_SHORT).show();
                }

            } else if (wifiP2pInfo.groupFormed) {                              // if only formed group/pair
                connectionStatus.setText("Client");                         // indicate device is a client

                clientClass = new ClientClass(groupOwnerAddress);           // InetAddress is that of group owner (acts as a standard address here)
                //clientClass.start();
                if (clientClass.availablePort(wifiP2pInfo.groupOwnerAddress.getHostAddress(), port[0]) == true) {
                    Toast.makeText(getApplicationContext(), "Connection #1 Available ", Toast.LENGTH_SHORT).show();
                }
                if (clientClass.availablePort(wifiP2pInfo.groupOwnerAddress.getHostAddress(), port[1]) == true) {
                    Toast.makeText(getApplicationContext(), "Connection #2 Available ", Toast.LENGTH_SHORT).show();
                }


                if ((clientClass.availablePort(groupOwnerAddress.getHostAddress(), port[0]) == true)&& (portInUse[0] == false)) {
                    Toast.makeText(getApplicationContext(), "Connect to 1111", Toast.LENGTH_SHORT).show();
                    clientClass.setPortNum(port[0]);
                    clientClass.start();                                        // start Client class
                    portInUse[0] = true;
                } else if (clientClass.availablePort(groupOwnerAddress.getHostAddress(), port[1]) == true) {
                    Toast.makeText(getApplicationContext(), "Connect to 2222 ", Toast.LENGTH_SHORT).show();
                    clientClass.setPortNum(port[1]);
                    clientClass.start();
                } else {
                    Toast.makeText(getApplicationContext(), "No more connections available ", Toast.LENGTH_SHORT).show();
                }
            }
            else {
                clientClass = new ClientClass(groupOwnerAddress);
                clientClass.setPortNum(port[1]);
                Toast.makeText(getApplicationContext(), "Connect to 2222 ", Toast.LENGTH_SHORT).show();
                clientClass.start();
            }

        }
    };

    @Override
    protected void onResume() {
        super.onResume();
        registerReceiver(mReceiver, mIntentFilter);                         // register the receiver with specified intents (when running) -> comes to the foreground of application (where app interacts with user)
    }

    @Override
    protected void onPause() {                                              // system calls as first indication user leaving activity (pause operations and assume to resume shortly after)
        super.onPause();
        unregisterReceiver(mReceiver);                                      // unregister receiver
    }

    public class ServerClass extends Thread {                               // create inner class for Server Class
        Socket socket;                                                      // standard socket
        ServerSocket serverSocket;                                          // server socket
        int portNum = 0001;


        public void setPortNum(int portNum){
            this.portNum = portNum;
        }


        @Override
        public void run() {
            try {
                serverSocket = new ServerSocket(portNum);                 // server socket connected to port 8888 (hard-coded)
                socket = serverSocket.accept();                             // accept connections/messages to this server
                sendReceive = new SendReceive(socket);                      // initiate transmission between two ends of port (with socket -> entrance to the terminal)
                sendReceive.start();                                        // start the method (exchange)
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

    }

    private class SendReceive extends Thread {                              // create send/receive thread (thread of execution of program -> can have multiple threads running concurrently -> potential to have multiple message transmissions within a session)
        private Socket socket;                                              // standard socket (with socket -> entrance to the terminal)
        private InputStream inputStream;                                    // create an inputstream (to read incoming messages) object
        private OutputStream outputStream;                                  // create an outputstream (to send outgoing messages) object

        public SendReceive(Socket sock) {
            socket=sock;                                                    // initialize socket through constructor
            try {
                inputStream = socket.getInputStream();                      // instantiate streams of the socket -> incoming stream to the socket
                outputStream = socket.getOutputStream();                    // instantiate streams of the socket -> outgoing stream from the socket
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        @Override
        public void run() {
            byte[] buffer = new byte[1024];                                 // buffer to store messages in (capped at 1024 bytes)
            int bytes;                                                      // bytes in message

            while (socket != null) {                                        // while there are still stuff/interactions with socket, ready to listen to message
                try {
                    bytes = inputStream.read(buffer);                       // read the amount of bytes in the buffer (read next byte from the inputstream), and assign to "bytes" (range of 0-255)
                    if (bytes > 0) {                                        // have something in the message (one or more bytes) -> return -1 if end of stream
                        handler.obtainMessage(MESSAGE_READ, bytes, -1, buffer).sendToTarget(); // read the message from the socket (sets the params: message.what, arg1/length, arg2, object)
                    }                                                                               // sendToTarget() sends to target previously specified in handler
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

        public void write(byte[] bytes) {                                   // for sending message to outputstream (as array of bytes)
            try {
                outputStream.write(bytes);                                  // send to output stream (as array of bytes (specified in param))
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public class ClientClass extends Thread {                               // inner class for Client Class
        Socket socket;                                                      // standard socket (entrance/virtual port to terminal)
        String hostAddr;                                                    // string for host address
        int portNum = 0001;

        public ClientClass(InetAddress hostAddress) {
            hostAddr = hostAddress.getHostAddress();                        // initialize hostAddr with device host address through constructor -> returns as a string
            socket = new Socket();                                          // initialize socket
        }
        public void setPortNum(int portNum){
            this.portNum = portNum;
        }

        public boolean availablePort(String host, int port) {
            // Assume port is available.
            boolean result = true;

            try {
                (new Socket(host, port)).close();


                result = false;         // Successful connection means the port is taken.
            }
            catch(Exception e) {        // Could not connect.
            }

            return result;
        }
        @Override
        public void run() {
            try {
                socket.connect(new InetSocketAddress(hostAddr, portNum), 2000);    // connect host address (with port 8888 -> same on server) to the server with timeout 2000 msec (removes list of peers if doesn't connected within that 2 seconds)
                sendReceive = new SendReceive(socket);                                      // initialize socket for transmission
                sendReceive.start();                                                        // start transmission service
            } catch (IOException e) {
                e.printStackTrace();
            }
        }


    }
}

/**
 * Android System notifies us about events of WiFi using Broadcast
 *
 * INTENTS: [1]
 * WIFI_P2P_STATE_CHANGE_ACTION -> indicates whether WiFi P2P is enabled/disabled
 * WIFI_P2P_PEERS_CHANGE_ACTION -> indicates that the available peer list has changed (when peer list changed, get new list using this intent)
 * WIFI_P2P_CONNECTION_CHANGED_ACTION -> indicates the state of WiFi P2P connectivity has changed
 * WIFI_P2P_THIS_DEVICE_CHANGED_ACTION -> indicates this device's configuration details have changed (ex. if name change)
 *
 * Using Broadcast Receiver and IntentFilter the receiver can be registered/unregistered
 *
 * discoverPeers(WifiP2pManager.Channel, WifiP2pManager.ActionListener) -> application discover peers, but no good way to figure out which peers to establish connection with [5]
 *      -> Pre-association service discovery tackles this issue by filtering the peers based on running services (specific applications running) [5]
 * */