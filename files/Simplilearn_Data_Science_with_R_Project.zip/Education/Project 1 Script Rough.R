# remember to change working directory to "/Data Science with R/Project/Project for Submission/Education" and load .RData

setwd(choose.dir())
myData = read.csv(file = "Project 1_Dataset_temp.csv", header = TRUE, sep = ",")

# using the data frame that was read in from csv (myData), append a new variable/column (GreLevels) with values based on gre scores
Aptitute_Descriptive = transform(myData, GreLevels=ifelse(gre<439,"Low",ifelse(gre<579,"Medium","High")))
Aptitute_Descriptive$GreLevels <- factor(Aptitute_Descriptive$GreLevels, levels = c("High", "Medium", "Low")) # make factor to order levels (from High to Low)
View(Aptitute_Descriptive)

Sum_Apt=aggregate(�..admit~GreLevels,Aptitute_Descriptive,FUN=sum)
length_Apt=aggregate(�..admit~GreLevels,Aptitute_Descriptive,FUN=length)

Probability_Table = cbind(Sum_Apt,Recs=length_Apt[,2])
Probability_Table_final = transform(Probability_Table,Probability_Admission = �..admit/Recs)
Probability_Table_final

library(ggplot2)
ggplot(Probability_Table_final,aes(x=GreLevels,y=Probability_Admission))+geom_point()
ggsave("Admission Probability vs GreLevels (rough).png", width = 5, height = 5)

table(Aptitute_Descriptive$�..admit,Aptitute_Descriptive$GreLevels)
