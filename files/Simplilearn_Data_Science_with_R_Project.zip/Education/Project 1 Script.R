# choose working directory (where csv dataset is saved) as to not use absolute file location
# read in the dataset that is saved formatted in csv (separator as ",") and save to data frame (myData)
setwd(choose.dir())
myData = read.csv(file = "Project 1_Dataset.csv", header = TRUE, sep = ",")

# according to the given cross grid for GRE categorization, assign a new variable/column to myData (GreCategorize)
# that uses "ordered" categorical data (make factor to assign the order of levels for representation in tables/plots)
Academic_Aptitude_Table = transform(myData, GreCategorize=ifelse(gre<439,"Low",ifelse(gre<579,"Medium","High")))
Academic_Aptitude_Table$GreCategorize <- factor(Academic_Aptitude_Table$GreCategorize, 
                                                levels = c("High", "Medium", "Low"))

# since admit is modeled/predicted by GreLevels -> admit~GreLevels. sum all admit values that grouped by GreCategorize
# length tracks how many records (ex: 38 record of "admit" (regardless if 0 or 1) for "Low" of GreLevels)
Sum_Admit_GreCat=aggregate(admit~GreCategorize,Academic_Aptitude_Table,FUN=sum)
Len_Admit_GreCat=aggregate(admit~GreCategorize,Academic_Aptitude_Table,FUN=length)

# category name, sum (from Sum_Admit_GreCat) and amount/records (from Len_Admit_GreCat) (store in Recds for probability)
# add a new variable to Table_Sum_Len to calculate Admission Probability as percent.
Table_Sum_Len = cbind(Sum_Admit_GreCat,Recds=Len_Admit_GreCat[,2])
ProbabilityTable_Admittance_Gre = transform(Table_Sum_Len,AdmissionProbabilityPercent = (admit/Recds)*100)
ProbabilityTable_Admittance_Gre

# after importing ggplot2, load the library to use it. then plot ProbabilityTable_Admittance_Gre in point chart format
# make GreCategorize the x-axis and AdmissionProbabolityPercent the y-axis
# use labs property to assign labels to title and axis, and element_text() to format
# save the image in the working directory
library(ggplot2)
ggplot(ProbabilityTable_Admittance_Gre,aes(x=GreCategorize,y=AdmissionProbabilityPercent))+geom_point()+
  labs(title="Admission Probability Due to GRE Scores", x="GRE Scores Categorized", y="Admission Probability (%)")+
  theme(plot.title = element_text(hjust = 0.5, face = "bold", size = (15)),
        axis.title = element_text(face = "bold"))
ggsave("Admission Probability vs GreLevels.png", width = 5, height = 5)

# Create frequency table that show how many admits/not admits in each category (x = admit, y = GreCategorize)
table(Academic_Aptitude_Table$admit,Academic_Aptitude_Table$GreCategorize)
