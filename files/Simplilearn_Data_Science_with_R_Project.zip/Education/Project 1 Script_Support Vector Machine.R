setwd(choose.dir())
myData = read.csv(file = "Project 1_Dataset.csv", header = TRUE, sep = ",")

library(plyr) # install to convert data to factors

# transform certain variables to factors
myData$admit <- sapply(myData$admit, factor)
myData$ses <- sapply(myData$ses, factor)
myData$Gender_Male <- sapply(myData$Gender_Male, factor)
myData$Race <- sapply(myData$Race, factor)
myData$rank <- sapply(myData$rank, factor)

# Split Data for Train = 70% (split = TRUE), Test = 30% (split = FALSE)
sample_split <- floor(.7 * nrow(myData)) # floor to have int (since can't have fraction of a row)
training <- sample(seq_len(nrow(myData)), size = sample_split) # randomizing selection of size = 70% dataset

train <- myData[training, ]
test <- myData[-training, ] # remaining 30% of data set

# Support Vector Machine (SVM) Model
library(e1071)

svm_myData = svm(admit ~ ., train) # '.' to include all data points (variables)

# assess accuracy of model -> confusion matrix
library(caret)
# build confusion matrix on train$admit variable and prediction of svm_myData, with positive value (if admit or not is 1)
confusionMatrix(train$admit, predict(svm_myData), positive = '1')

# prediction on test data from actual data
prediction <- predict(svm_myData, test[-1]) # svm on test dataset

# get prediction results
prediction_results <- table(pred=prediction, true=test[,1])
prediction_results 

sum(diag(prediction_results))/sum(prediction_results)
