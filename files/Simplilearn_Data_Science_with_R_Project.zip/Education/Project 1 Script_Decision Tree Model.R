setwd(choose.dir())
myData = read.csv(file = "Project 1_Dataset.csv", header = TRUE, sep = ",")

# load necessary packages
library(e1071)
library(plyr) # use apply function (transform int to factors)
library(caret)
library(mlbench)
library(rpart) # used to create decision tree
library(rpart.plot) # used to plot decision tree with names

# transform certain variables to factors (classification)
myData$admit <- sapply(myData$admit, factor)
myData$ses <- sapply(myData$ses, factor)
myData$Gender_Male <- sapply(myData$Gender_Male, factor)
myData$Race <- sapply(myData$Race, factor)
myData$rank <- sapply(myData$rank, factor)

# split data set to train/test using 70:30 ratio
sample_split <- floor(.9 * nrow(myData))
trainIndex <- sample(seq_len(nrow(myData)), size = sample_split)
train <- myData[trainIndex, ]
test <- myData[-trainIndex, ]

# build the Decision Tree Model
tree_model <- rpart(admit ~ ., data = train, method = "class", parms = list(split = "information")) # method="class" for classification
tree_model

# analyze results
printcp(tree_model) # print for rpart object (decision tree)
plotcp(tree_model)  # as size of tree increase, relative error increase till around size=6, then error decrease
summary(tree_model) # cleaner view of what splits look like
plot(tree_model) # shows decison tree
rpart.plot(tree_model, box.palette="RdBu", shadow.col="gray", nn=TRUE)

# predict using test data
prediction <- predict(tree_model, test, type = "class")

# create confusion matrix
confMat <- table(test$admit, prediction)
confMat

accuracy <- sum(diag(confMat))/sum(confMat)
accuracy # 63% with 70:30, 65% with 80:20, 72.5% with 90:10
