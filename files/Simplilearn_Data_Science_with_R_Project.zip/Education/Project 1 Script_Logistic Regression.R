setwd(choose.dir())
myData = read.csv(file = "Project 1_Dataset.csv", header = TRUE, sep = ",")

install.packages("caTools")
library(caTools)

# Split Data for Train = 70% (split = TRUE), Test = 30% (split = FALSE)
split <- sample.split(myData, SplitRatio = 0.7)
train <- subset(myData, split == "TRUE")
test <- subset(myData, split == "FALSE")

# Convert categorical data to factors
myData$admit = as.factor(myData$admit)
myData$ses = as.factor(myData$ses)
myData$Gender_Male = as.factor(myData$Gender_Male)
myData$Race = as.factor(myData$Race)
myData$rank = as.factor(myData$rank)

# train model using "train" data. Dependent = admit, independent = [rest of variables]
# family = binomial (logistic regression)
myModel <- glm(admit ~ gre + gpa + ses + Gender_Male + Race + rank, data = train, family = 'binomial')
summary(myModel)

# run test data through model
res <- predict(myModel, test.type="response")
res <- predict(myModel, train.type="response")

# Validate the model - Confusion Matrix
confmatrix = table(Actual_Value = train$admit, Predicted_Value = res > 0.5)
confmatrix

# Accuracy (what predicted right / all predictions)
(confmatrix[[1,1]] + confmatrix[[2,2]])/sum(confmatrix) # 72.37%

# myModel1 <- glm(admit ~ gpa + Race + rank, data = train, family = 'binomial')
# res1 <- predict(myModel1, test.type="response")
# res1 <- predict(myModel1, train.type="response")
# confmatrix1 = table(Actual_Value = train$admit, Predicted_Value = res1 > 0.5)
# confmatrix1
# (confmatrix1[[1,1]] + confmatrix1[[2,2]])/sum(confmatrix1) # 72.81%

# Conclusion -> significant variables: rank (0.000176 significant)
#            -> Accuracy: 72.37%
#            -> To factors from numeric: Admission, Session, Gender, Race, rank
