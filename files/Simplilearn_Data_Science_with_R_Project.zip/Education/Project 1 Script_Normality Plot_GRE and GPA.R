library(ggplot2)
ggplot(Academic_Aptitude_Table, aes(x=gre)) + geom_density() + 
  labs(title = "Density Plot for GRE Scores") +
  theme(plot.title = element_text(hjust = 0.5, face = "bold", size = (15)))
        
ggplot(Academic_Aptitude_Table, aes(x=gpa)) + geom_density() + 
  labs(title = "Density Plot for GPA Results") +
  theme(plot.title = element_text(hjust = 0.5, face = "bold", size = (15)))
