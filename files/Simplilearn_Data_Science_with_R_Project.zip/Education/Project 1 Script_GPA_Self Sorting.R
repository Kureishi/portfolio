# quantile(Academic_Aptitude_Table$gpa)
# 0%    25%   50%   75%   100% 
# 2.260 3.130 3.395 3.670 4.000 

setwd(choose.dir())
myData = read.csv(file = "Project 1_Dataset.csv", header = TRUE, sep = ",")

Academic_Aptitude_Table = transform(myData, GpaCategorize=ifelse(gpa<3.13,"Low",ifelse(gpa<3.67,"Medium","High")))
Academic_Aptitude_Table$GpaCategorize <- factor(Academic_Aptitude_Table$GpaCategorize, 
                                                levels = c("High", "Medium", "Low"))

Sum_Admit_GpaCat=aggregate(admit~GpaCategorize,Academic_Aptitude_Table,FUN=sum)
Len_Admit_GpaCat=aggregate(admit~GpaCategorize,Academic_Aptitude_Table,FUN=length)

Table_Sum_Len_GPA = cbind(Sum_Admit_GpaCat,Recds=Len_Admit_GpaCat[,2])
ProbabilityTable_Admittance_Gpa = transform(Table_Sum_Len_GPA,AdmissionProbabilityPercent_GPA = (admit/Recds)*100)
ProbabilityTable_Admittance_Gpa

library(ggplot2)
ggplot(ProbabilityTable_Admittance_Gpa,aes(x=GpaCategorize,y=AdmissionProbabilityPercent_GPA))+geom_point()+
  labs(title="Admission Probability Due to GPA Scores", x="GPA Scores Categorized", y="Admission Probability (%)")+
  theme(plot.title = element_text(hjust = 0.5, face = "bold", size = (15)),
        axis.title = element_text(face = "bold"))
ggsave("Admission Probability vs GpaLevels.png", width = 5, height = 5)

table(Academic_Aptitude_Table$admit,Academic_Aptitude_Table$GpaCategorize)
