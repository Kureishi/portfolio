/*----------------------------------------------------------------------------
 * Name:    usbmain.c
 * Purpose: USB Audio Class Demo
 * Version: V1.20
 *----------------------------------------------------------------------------
 *      This software is supplied "AS IS" without any warranties, express,
 *      implied or statutory, including but not limited to the implied
 *      warranties of fitness for purpose, satisfactory quality and
 *      noninfringement. Keil extends you a royalty-free right to reproduce
 *      and distribute executable files created using this software for use
 *      on NXP Semiconductors LPC microcontroller devices only. Nothing else 
 *      gives you the right to use this software.
 *
 * Copyright (c) 2009 Keil - An ARM Company. All rights reserved.
 *---------------------------------------------------------------------------*/

#include "LPC17xx.h"                        /* LPC17xx definitions */
#include "type.h"

#include "usb.h"
#include "usbcfg.h"
#include "usbhw.h"
#include "usbcore.h"
#include "usbaudio.h"
//#include "system_LPC17xx.c"




                    /* NXP LPC17xx definitions            */
#include "string.h"
#include "GLCD.h"
#include "LED.h"
#include "KBD.h"
#define __FI        1 
extern unsigned char ClockLEDOn;
extern unsigned char ClockLEDOff;
extern unsigned char ClockANI;

extern unsigned char image[];
extern unsigned char image1[];
extern unsigned char image2[];
extern unsigned char image4[];



extern  void SystemClockUpdate(void);
extern uint32_t SystemFrequency;  
uint8_t  Mute;                                 /* Mute State */
uint32_t Volume;  
int rep;                         /* Volume Level */

char str [50];		// used to display score at end of game
int score;


// GAME VARIABLES
int a=5,b=9,c=1,hold1=0;	// for position
int a1=5,b1=8,c1=0;
int a2=0,b2=0,c2=0;
int tail[1][18];					// tail: length of array of food
int snake=0;							// po: the actual array of food
int p=0;									// placeholder
int i2=1,i3=0;						// to go through arrays
int check=0,check2=0;			// indicators

#if USB_DMA
uint32_t *InfoBuf = (uint32_t *)(DMA_BUF_ADR);
short *DataBuf = (short *)(DMA_BUF_ADR + 4*P_C);
#else
uint32_t InfoBuf[P_C];
short DataBuf[B_S];                         /* Data Buffer */
#endif

uint16_t  DataOut;                              /* Data Out Index */
uint16_t  DataIn;                               /* Data In Index */

uint8_t   DataRun;                              /* Data Stream Run State */
uint16_t  PotVal;                               /* Potenciometer Value */
uint32_t  VUM;                                  /* VU Meter */
uint32_t  Tick;                                 /* Time Tick */


/*
 * Get Potenciometer Value
 */

void get_potval (void) {
  uint32_t val;

  LPC_ADC->CR |= 0x01000000;              /* Start A/D Conversion */
  do {
    val = LPC_ADC->GDR;                   /* Read A/D Data Register */
  } while ((val & 0x80000000) == 0);      /* Wait for end of A/D Conversion */
  LPC_ADC->CR &= ~0x01000000;             /* Stop A/D Conversion */
  PotVal = ((val >> 8) & 0xF8) +          /* Extract Potenciometer Value */
           ((val >> 7) & 0x08);
}


/*
 * Timer Counter 0 Interrupt Service Routine
 *   executed each 31.25us (32kHz frequency)
 */

void TIMER0_IRQHandler(void) 
{
  long  val;
  uint32_t cnt;

  if (DataRun) {                            /* Data Stream is running */
    val = DataBuf[DataOut];                 /* Get Audio Sample */
    cnt = (DataIn - DataOut) & (B_S - 1);   /* Buffer Data Count */
    if (cnt == (B_S - P_C*P_S)) {           /* Too much Data in Buffer */
      DataOut++;                            /* Skip one Sample */
    }
    if (cnt > (P_C*P_S)) {                  /* Still enough Data in Buffer */
      DataOut++;                            /* Update Data Out Index */
    }
    DataOut &= B_S - 1;                     /* Adjust Buffer Out Index */
    if (val < 0) VUM -= val;                /* Accumulate Neg Value */
    else         VUM += val;                /* Accumulate Pos Value */
    val  *= Volume;                         /* Apply Volume Level */
    val >>= 16;                             /* Adjust Value */
    val  += 0x8000;                         /* Add Bias */
    val  &= 0xFFFF;                         /* Mask Value */
  } else {
    val = 0x8000;                           /* DAC Middle Point */
  }

  if (Mute) {
    val = 0x8000;                           /* DAC Middle Point */
  }

  LPC_DAC->CR = val & 0xFFC0;             /* Set Speaker Output */

  if ((Tick++ & 0x03FF) == 0) {             /* On every 1024th Tick */
    get_potval();                           /* Get Potenciometer Value */
    if (VolCur == 0x8000) {                 /* Check for Minimum Level */
      Volume = 0;                           /* No Sound */
    } else {
      Volume = VolCur * PotVal;             /* Chained Volume Level */
    }
    val = VUM >> 20;                        /* Scale Accumulated Value */
    VUM = 0;                                /* Clear VUM */
    if (val > 7) val = 7;                   /* Limit Value */
  }
	
	if(get_button() == KBD_LEFT) {						// to turn off music player
		NVIC_DisableIRQ(TIMER0_IRQn);
		NVIC_DisableIRQ(USB_IRQn);
		USB_Connect(FALSE);
		USB_Reset();
		USB_Connect(TRUE);
	}
	
  LPC_TIM0->IR = 1;                         /* Clear Interrupt Flag */
}

void delay(int g){
	int p,b;
	int i = 0;
	for (p = 0; p < g; p++){
		b = p+1;
	}
}

void music() {									// make audio player a function to be activated when the specific option is pressed
	int d = 1;
	GLCD_Clear  (White);
			GLCD_DisplayString(2, 5, __FI, " Music ");
			GLCD_Bitmap (  120,   90, 50,  50, image4);
			while(d<10){
			 volatile uint32_t pclkdiv, pclk;

  /* SystemClockUpdate() updates the SystemFrequency variable */
  SystemClockUpdate();

  LPC_PINCON->PINSEL1 &=~((0x03<<18)|(0x03<<20));  
  /* P0.25, A0.0, function 01, P0.26 AOUT, function 10 */
  LPC_PINCON->PINSEL1 |= ((0x01<<18)|(0x02<<20));

  /* Enable CLOCK into ADC controller */
  LPC_SC->PCONP |= (1 << 12);

  LPC_ADC->CR = 0x00200E04;		/* ADC: 10-bit AIN2 @ 4MHz */
  LPC_DAC->CR = 0x00008000;		/* DAC Output set to Middle Point */

  /* By default, the PCLKSELx value is zero, thus, the PCLK for
  all the peripherals is 1/4 of the SystemFrequency. */
  /* Bit 2~3 is for TIMER0 */
  pclkdiv = (LPC_SC->PCLKSEL0 >> 2) & 0x03;
  switch ( pclkdiv )
  {
	case 0x00:
	default:
	  pclk = SystemFrequency/4;
	break;
	case 0x01:
	  pclk = SystemFrequency;
	break; 
	case 0x02:
	  pclk = SystemFrequency/2;
	break; 
	case 0x03:
	  pclk = SystemFrequency/8;
	break;
  }
	//if(get_button() == 0x01){
	//	d=12;}
		LPC_TIM0->MR0 = pclk/DATA_FREQ - 1;	/* TC0 Match Value 0 */
		LPC_TIM0->MCR = 3;					/* TCO Interrupt and Reset on MR0 */
		LPC_TIM0->TCR = 1;					/* TC0 Enable */
		NVIC_EnableIRQ(TIMER0_IRQn);

	USB_Init();				/* USB Initialization */
	USB_Connect(TRUE);		/* USB Connect */
//		delay(50000000);																					//////////////////added to return from interrupt
//			NVIC_DisableIRQ(TIMER0_IRQn);
//				NVIC_DisableIRQ(USB_IRQn);
//				USB_Connect(FALSE);
//				USB_Reset();
	
	main(); //////////////////////////////////////////////////// to loop back to main
	}
}

// Game Functions
void mov(){									// how the snake moves

 hold1 = get_button(); 
 if(hold1==0x10){						//right
		c=1;
 }else if(hold1==0x08){			//up
		c=2;
 }else if(hold1==0x20){			//down
		c=3;
 }else if(hold1==0x40){			//left
		c=4;
 }
 
 if(c1==1){									// when direction is right
	 if(c==1){								// positions that come after right
		 b1=b;
		 b=b+1;
		 a1=a;
	 }else if(c==4){
		 b1=b;
		 b=b+1;
		 a1=a;
	 }else if(c==2){
		 a1=a;
		 a=a-1;
		 b1=b;
		 c1=c;
	 }else if(c==3){
		a1=a;
		 a=a+1;
		 b1=b;
		c1=c;
	 }
 
 }else if(c1==2){						// when direction is up
	 if(c==1){								// positions that come after up
		 b1=b;
		 b=b+1;
		 a1=a;
		 c1=c;
	 }else if(c==4){
		 b1=b1;
		 b=b-1;
		 a1=a;
		 c1=c;
	 }else if(c==2){
		 a1=a;
		 a=a-1;
		 b1=b;
	 }else if(c==3){
		 a1=a;
		 a=a-1;
		 b1=b;
	 }

 }else if(c1==3){					  // when direction is down
	 if(c==1){								// positions that come after down
		 b1=b;									// the a's, b's, and c's are place holder for position
		 b=b+1;
		 a1=a;
		 c1=c;
	 }else if(c==4){
		 b1=b;
		 b=b-1;
		 a1=a;
		 c1=c;
	 }else if(c==2){
		 a1=a;
		 a=a+1;
		 b1=b;
	 }else if(c==3){
		 a1=a;
		 a=a+1;
		 b1=b;
	 }
 
 }else if(c1==4){						// when direction is left
	 if(c==1){								// positions that come after left
		 b1=b;
		 b=b-1;
		 a1=a;
	 }else if(c==4){
		 b1=b;
		 b=b-1;
		 a1=a;
		// c1=c;
	 }else if(c==2){
		 a1=a;
		 a=a-1;
		 b1=b;
		c1=c;
	 }else if(c==3){
		 a1=a;
		 a=a+1;
		 b1=b;
		 c1=c;
	 }
 }
 
 p=0,i2=0;

 for(;i2<(snake);i2++){
 tail[0][i2]=tail[0][i2+1]; // move head to new line, and delete one of the tail (give impression moving through frames)
 tail[1][i2]=tail[1][i2+1];
	 p=i2;
 }
 
 tail[0][snake]=a; // beginning and end of snake
 tail[1][snake]=b;
 GLCD_DisplayString( tail[0][0],  tail[1][0], __FI, " ");
 GLCD_DisplayString( tail[0][snake], tail[1][snake], __FI, "o"); // added 'o' to represent additions to tail
		
 for(i3=0;i3<(snake);i3++){
			if((tail[0][snake]==tail[0][i3])&&(tail[1][snake]==tail[1][i3]))		// if head of snake touches the body...
				check2=1;																													// an indicator
		}	
 }

 void food(){					// for the food
	
 while(1){
	a2=rand()%(8+1-1)+1;		//number generated within border heigtht
	b2=(rand()%(18+1-1)+1); //number generated within border width
		i2=0;
		check=0;
		for(;i2<(snake);i2++){
			if((tail[0][a2]==tail[0][i2])&&(tail[1][b2]==tail[1][i2]))	// if the random function places food on top of sanke...
				check=1;		//...make cd=1 as an indicator
		}
		if(check==0)
			break;		// if its fine, then break out of it
	}
	c2=1;
	GLCD_DisplayString(a2, b2, __FI, "$");											// what the food looks like
}
 
void gg(){																										// what to do when user loses (game over)

GLCD_DisplayString(0, 0, __FI, "XXXXXXXXXXXXXXXXXXXX");				// display of the screen when player loses
GLCD_DisplayString(1, 0, __FI, "X                  X");
GLCD_DisplayString(2, 0, __FI, "X                  X");
GLCD_DisplayString(3, 0, __FI, "X                  X");
GLCD_DisplayString(4, 0, __FI, "X                  X");
GLCD_DisplayString(5, 0, __FI, "X   GAME OVER -_-  X");
GLCD_DisplayString(6, 0, __FI, (unsigned char *)str);
GLCD_DisplayString(7, 0, __FI, "X                  X");
GLCD_DisplayString(8, 0, __FI, "X                  X");
GLCD_DisplayString(9, 0, __FI, "XXXXXXXXXXXXXXXXXXXX");				//10x20
	
 while(1){
	delay(5000000);
	hold1 = get_button(); 
	if(hold1 == 0x01)
	 break;
	}	
}

void game(){																									//actual game
	int hold=0;
	check2=0;
  GLCD_Clear(White);                         /* Clear graphical LCD display   */
  GLCD_SetBackColor(Green);
  GLCD_SetTextColor(Red);

	GLCD_DisplayString(0, 0, __FI, "XXXXXXXXXXXXXXXXXXXX");			// display of the screen when user is playing the game
	GLCD_DisplayString(1, 0, __FI, "X                  X");
	GLCD_DisplayString(2, 0, __FI, "X                  X");
	GLCD_DisplayString(3, 0, __FI, "X                  X");
	GLCD_DisplayString(4, 0, __FI, "X                  X");
	GLCD_DisplayString(5, 0, __FI, "X                  X");
	GLCD_DisplayString(6, 0, __FI, "X                  X");
	GLCD_DisplayString(7, 0, __FI, "X                  X");
	GLCD_DisplayString(8, 0, __FI, "X                  X");
	GLCD_DisplayString(9, 0, __FI, "XXXXXXXXXXXXXXXXXXXX");			//Borders are 10x20
	a=5,b=9,c=1,a1=5,b1=9,c1=1,hold1=0,a2=0,b2=0,c2=0,snake=1;			// the position of "snake" game just begin
		while(1){

			mov();																									// starts to move
			
			if(c2==0){																							// check if food is eaten (to be eaten)
				food();						
			}
			if((a2==a1)&&(b2==b1)){																	// if snake goes to where food is
				c2=0;
				
				snake=snake+1;			// update the score
				score = snake-1;		// score to print
				
				sprintf(str, "X   Score: %       X", score);		// used to print final score on screen
			}
			if((a1==0)||(a1==9)||(b1==0)||(b1==20)){			// if hit the border
				gg();																									//game over or ...
				break;
			}
			if(check2==1){																							// if head touch any part of body
				gg();																									//... game over
				break;
			}
			delay(5000000);
			if(get_button() == 0x01)																// if joystick is pressed (select)
				break;
			}
	GLCD_Clear(White);
	GLCD_SetTextColor(Black);
	GLCD_DisplayString(0, 1, __FI, "***Media Center***");
	GLCD_DisplayString(2, 5, __FI, " Pictures ");
  GLCD_DisplayString(4, 5, __FI, " Music ");
	GLCD_DisplayString(6, 5, __FI, " Game (Snake)");	
}

/*****************************************************************************
**   Main Function  main()
******************************************************************************/

int main (void) {                       /* Main Program                       */
  int num     = -1; 
  int dir     =  1;
  int pic     =  0;
  int select = 3, a = 1, b, c;
	int i = 0;
	uint32_t ad_avg = 0, getthenumber, getthebutton;
  LED_Init ();
  GLCD_Init();
  KBD_get ();
	get_button ();
	
	GLCD_Clear  (White);
	   GLCD_SetTextColor(Black);
	GLCD_DisplayString(0, 1, __FI, "***Media Center***");
	  GLCD_DisplayString(2, 5, __FI, " Pictures ");
  GLCD_DisplayString(4, 5, __FI, " Music ");
	 GLCD_DisplayString(6, 5, __FI, " Game (Snake)");	
	
	while(1){
		 getthebutton = get_button(); 
		if(getthebutton == 0x08){    //up
			LED_On(3);
			LED_Off(4);
			if(select == 1){
				select = 3;}
			else if(select == 2){
				select = 1;}
			else if(select == 3){
				select = 2;}
	}
	
		if(getthebutton == 0x20){     //down
			LED_On(4);
			LED_Off(3);
			if(select == 1){
				select = 2;}
			else if(select == 2){
				select = 3;}
			else if(select == 3){
				select = 1;}
	}
		
		if(getthebutton == 0x01){		//	select
			if(select == 1){
				GLCD_Bitmap (  0,   0, 320,  240, image1);}
			else if(select == 2){
				select = 2;}
			else if(select == 3){
				select = 3;}
	}
			
	
			if(select == 1){
				a = 2; b = 4; c = 6;
			}
			if(select == 2){
				a = 4; b = 6; c = 2;
				}
			if(select == 3){
				a = 6; b = 2; c = 4;
				}
delay(2000000);
	GLCD_DisplayString(a, 4, __FI, ">");
	GLCD_DisplayString(b, 4, __FI, "  ");
	GLCD_DisplayString(c, 4, __FI, "  ");
		if(getthebutton == 0x01){		//	select
			
			if(select == 1){								// plays the photo gallery
				GLCD_Clear  (White);
				GLCD_Bitmap (  0,  0, 200,  200, image1);  
		delay(50000000);
					GLCD_Clear  (White);
			GLCD_Bitmap (  0,   0, 200,  200, image);
		delay(50000000);
					GLCD_Clear  (White);
			GLCD_Bitmap (  0,   0, 200,  200, image2);
delay(50000000);
					GLCD_Clear  (White);		
					
					GLCD_DisplayString(0, 1, __FI, "***Media Center***");
				
					GLCD_DisplayString(2, 5, __FI, " Pictures ");
					GLCD_DisplayString(4, 5, __FI, " Music ");
					GLCD_DisplayString(6, 5, __FI, " Game (Snake)");			
			}
				

		if(select == 2){		// if cursor is is at position 2 that is predefined
			music();					// music function
			
		}
		
		if(select == 3){
			game();
		}
  /********* The main Function is an endless loop ***********/ 
 

/******************************************************************************
**                            End Of File
******************************************************************************/

		}
	}
}