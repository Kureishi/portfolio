/*----------------------------------------------------------------------------
 * Name:    Blinky.c
 * Purpose: LED Flasher and Graphic Demo
 * Note(s): 
 *----------------------------------------------------------------------------
 * This file is part of the uVision/ARM development tools.
 * This software may only be used under the terms of a valid, current,
 * end user licence from KEIL for a compatible version of KEIL software
 * development tools. Nothing else gives you the right to use this software.
 *
 * This software is supplied "AS IS" without warranties of any kind.
 *
 * Copyright (c) 2008-2011 Keil - An ARM Company. All rights reserved.
 *----------------------------------------------------------------------------*/
                  
#include <LPC17xx.H>                    /* NXP LPC17xx definitions            */
#include "string.h"
#include "GLCD.h"
#include "LED.h"
#include "KBD.h"
#define __FI        1 
extern unsigned char ClockLEDOn;
extern unsigned char ClockLEDOff;
extern unsigned char ClockANI;

extern unsigned char G[];
extern unsigned char dodge[];

void delay(int g){
	int p,b;
	int i = 0;
	for (p = 0; p < g; p++){
		b = p+1;
	}
}

/*----------------------------------------------------------------------------
  Main Program
 *----------------------------------------------------------------------------*/
int main (void) {                       /* Main Program                       */
  int num     = -1; 
  int dir     =  1;
  int pic     =  0;
  int select = 3, a = 1, b, c;
	int i = 0;
	uint32_t ad_avg = 0, getthenumber, getthebutton;
  LED_Init ();
  GLCD_Init();
  KBD_get ();
	get_button ();
	
	GLCD_Clear  (White);
	   GLCD_SetTextColor(Black);
	  GLCD_DisplayString(2, 5, __FI, " Pictures ");
  GLCD_DisplayString(4, 5, __FI, " Music ");
	 GLCD_DisplayString(6, 5, __FI, " Game ");
	
	while(1){
		 getthebutton = get_button(); 
		if(getthebutton == 0x08){    //up
			LED_On(3);
			LED_Off(4);
			if(select == 1){
				select = 3;}
			else if(select == 2){
				select = 1;}
			else if(select == 3){
				select = 2;}
	}
	
	
		
		if(getthebutton == 0x20){     //down
			LED_On(4);
			LED_Off(3);
			if(select == 1){
				select = 2;}
			else if(select == 2){
				select = 3;}
			else if(select == 3){
				select = 1;}
	}
		
		if(getthebutton == 0x01){		//	selecy
			if(select == 1){
				GLCD_Bitmap (  0,   0, 320,  240, dodge+140);}
			else if(select == 2){
				select = 2;}
			else if(select == 3){
				select = 3;}
	}
			
	
			if(select == 1){
				a = 2; b = 4; c = 6;
			//	GLCD_DisplayString(2, 4, __FI, "* ");
			}
			if(select == 2){
				a = 4; b = 6; c = 2;
			//	GLCD_DisplayString(4, 4, __FI, "* ");
				}
			if(select == 3){
				a = 6; b = 2; c = 4;
				//GLCD_DisplayString(6, 4, __FI, "* ");
				}
delay(2000000);
	GLCD_DisplayString(a, 4, __FI, "* ");
	GLCD_DisplayString(b, 4, __FI, "  ");
	GLCD_DisplayString(c, 4, __FI, "  ");
		if(getthebutton == 0x01){		//	selecy
			if(select == 1){
				GLCD_Clear  (White);
				GLCD_Bitmap (  0,   0, 320,  240, dodge+140);
		delay(50000000);
					GLCD_Clear  (White);
			GLCD_Bitmap (  100,   70, 130,  130, G);
delay(50000000);
					GLCD_Clear  (White);				
				GLCD_DisplayString(2, 5, __FI, " Pictures ");
					GLCD_DisplayString(4, 5, __FI, " Music ");
					GLCD_DisplayString(6, 5, __FI, " Game ");
				GLCD_DisplayString(8, 0, __FI, " Daniel Iafrate ");
				
			}
				
		
	
		
		if(select == 2)
			select = 2;
		}
//LED_Out(6);
 //GLCD_Bitmap (  0,   0, 320,  240, dodge+140);
//  GLCD_Bitmap (  0,  69,   4, 102, Bg_16bpp_l+70);
//  GLCD_Bitmap (316,  69,   4, 102, Bg_16bpp_r+70);
//  GLCD_Bitmap (  0, 171, 320,  69, Bg_16bpp_b+70);

  SysTick_Config(SystemCoreClock/100);  /* Generate interrupt every 10 ms     */


}}
