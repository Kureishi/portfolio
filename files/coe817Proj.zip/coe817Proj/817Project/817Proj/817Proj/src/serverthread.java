/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.net.*;
import java.io.*;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.crypto.SecretKey;
import javax.xml.bind.DatatypeConverter;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
/**
 *
 * @author garrett
 */
public class serverthread extends Thread {
    protected Socket socket;
    static ArrayList<PrintWriter> clients = new ArrayList<PrintWriter>();
    static int ClientID = 1;
    private final String password="password";
    
    public serverthread(Socket clientSocket) {
        this.socket = clientSocket;
    }

    public void run() {
        BufferedReader in;
        PrintWriter out;
        String msg="";
        String id="";
        
        //getting the socket communication read and write
        try {
            in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            out = new PrintWriter(socket.getOutputStream(), true);
            clients.add(out);
        } catch (IOException e) {
            return;
        }
        
        try {
            //notifies all connected people which user has connected
            id = in.readLine();
            msg = in.readLine();
        } catch (IOException ex) {
            Logger.getLogger(serverthread.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        //Check password
        if(msg.equals(password)){
            msg = "Client "+id+" has connected\n";
            for(PrintWriter client: clients){
                client.println(msg);
            }
        }
        else{
            //send a fail report
            String reply="wrong password";
            out.println(reply);
            return;
        }
        
        while (true) {
            try {
                //getting the message to be sent
                msg = in.readLine();
                if ((msg == null) || msg.equalsIgnoreCase("LEAVE")) {
                    socket.close();
                    //notifies all connected people that a user has disconnected
                    msg = "Client "+id+" has left";
                    for(PrintWriter client: clients){
                        client.println(msg);
                    }
                    return;
                }
                else {
                    //broadcasts all the messages received
                    System.out.println(msg);
                    for(PrintWriter client: clients){
                        client.println(msg);
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
                return;
            }
        }
    }
}
