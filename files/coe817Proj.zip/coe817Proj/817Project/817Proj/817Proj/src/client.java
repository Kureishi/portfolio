/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.net.*;
import java.io.*;
import java.util.Scanner;
import javax.crypto.SecretKey;
import javax.xml.bind.DatatypeConverter;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
/**
 *
 * @author garrett
 */
public class client {
    public static void main(String[] args) throws Exception{
        String receive="";
        Scanner sc = new Scanner(System.in);
        Socket s = new Socket("127.0.0.1", 16000);
        PrintWriter out = new PrintWriter(s.getOutputStream(), true);
        BufferedReader in = new BufferedReader(new InputStreamReader(s.getInputStream()));

        System.out.println("Client");
        String msg;
        
        //get the user's name
        System.out.println("WHO ARE YOU?");
        msg = sc.nextLine();
        out.println(msg);
        System.out.println("Enter the password");
        msg = sc.nextLine();
        out.println(msg);
        
        receive = in.readLine();
        
        if(!(receive.equals("wrong password"))){
            //allows for the user to have a concurrent update for the message reception
            if(s != null)
                new clientThread(in).start();

            System.out.println();
            //get the message to be broadcasted
            while(true){
                msg = sc.nextLine();
                out.println(msg);
                if(msg.equals("LEAVE"))
                    break;
            }
        }
        else
            System.out.println(receive);
        in.close();
        out.close();
        s.close();
    }
}
