import javax.crypto.Cipher;
import javax.crypto.SecretKey;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author garrett
 */

import java.util.Scanner; 
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;

public class JDESencrypt {
    
  Cipher ecipher;
  Cipher dcipher;

  JDESencrypt(SecretKey key) throws Exception {
    ecipher = Cipher.getInstance("DES");
    dcipher = Cipher.getInstance("DES");
    ecipher.init(Cipher.ENCRYPT_MODE, key);
    dcipher.init(Cipher.DECRYPT_MODE, key);
  }

  public String encrypt(String str) throws Exception {
    // Encode the string into bytes using utf-8
    byte[] encodeBytes = str.getBytes("UTF8");

    // Encrypt
    byte[] encode = ecipher.doFinal(encodeBytes);

    // Encode bytes to base64 to get a string
    return new sun.misc.BASE64Encoder().encode(encode);
  }

  public String decrypt(String str) throws Exception {
    // Decode base64 to get bytes
    byte[] decode = new sun.misc.BASE64Decoder().decodeBuffer(str);

    byte[] utf8 = dcipher.doFinal(decode);

    // Decode using utf-8
    return new String(utf8, "UTF8");
  }   
}