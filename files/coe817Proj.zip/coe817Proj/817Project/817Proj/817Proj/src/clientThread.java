
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author garrett
 */
public class clientThread extends Thread {
    private BufferedReader in;
    
    public clientThread(BufferedReader in) {
        this.in = in;
    }

    public void run() {
        String msg="";
       //getting the message from the server to be displayed for a user
        while (msg != null) {
            try {
                msg = in.readLine();
                System.out.println(msg);
            } catch (IOException ex) {
                Logger.getLogger(clientThread.class.getName()).log(Level.SEVERE, null, ex);
            }
            
        }
    }
    
}
