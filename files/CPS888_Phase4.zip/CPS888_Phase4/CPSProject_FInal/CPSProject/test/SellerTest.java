import java.io.ByteArrayInputStream;
import java.util.Scanner;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

public class SellerTest {
    
    public SellerTest() {
    }

    @BeforeClass
    public static void setUpClass() throws Exception {
    }

    @AfterClass
    public static void tearDownClass() throws Exception {
    }

    @Before
    public void setUp() throws Exception {
    }

    @After
    public void tearDown() throws Exception {
    }
    
//    @BeforeClass
//    public static void setUpClass() {
//    }
//    
//    @AfterClass
//    public static void tearDownClass() {
//    }
//    
//    @Before
//    public void setUp() {
//    }
//    
//    @After
//    public void tearDown() {
//    }

     // Coverage test of sell function when all inputs meet constraints
    // covers all lines of code in the first else statement
    
    @Test
    public void testSell1() {
        System.out.println("sell");
        
        System.out.println("buy");
        
        Seller instance = new Seller("sam", 972.0);
        
        String data = "leafsgame" + "\n20.00" + "\n10";
        System.setIn(new ByteArrayInputStream(data.getBytes()));
        Scanner input = new Scanner(System.in);
        
        boolean expResult = true;
        boolean result = instance.sell(input);
        assertEquals(expResult, result);
    }
    
    // Coverage test of sell function when all inputs meet constraints
    // covers all lines of code in the third if-statement
    
    @Test
    public void testSell2() {
        System.out.println("sell");
        
        System.out.println("buy");
        
        Seller instance = new Seller("sam", 972.0);
        
        String data = "raptorsgame" + "\n20.00" + "\n10";
        System.setIn(new ByteArrayInputStream(data.getBytes()));
        Scanner input = new Scanner(System.in);
        
        boolean expResult = true;
        boolean result = instance.sell(input);
        assertEquals(expResult, result);
    }
 
    // Coverage test of sell function when event title is longer than the specified number of characters
    // covers all lines of code except the first if-statement
    @Test
    public void testSell3() {
        System.out.println("sell");
        
        System.out.println("buy");
        
        Seller instance = new Seller("sam", 972.0);
        
        String data = "reallylongeventtitlenamethatwontwork" + "\n20.00" + "\n10";
        System.setIn(new ByteArrayInputStream(data.getBytes()));
        Scanner input = new Scanner(System.in);
        
        boolean expResult = false;
        boolean result = instance.sell(input);
        assertEquals(expResult, result);
    }
    

    // Coverage test of sell function when ticket price is greater than 1000
    // covers all lines of code except the first if-statement
    @Test
    public void testSell4() {
        System.out.println("sell");
        
        System.out.println("buy");
        
        Seller instance = new Seller("sam", 972.0);
        
        String data = "raptorsgame" + "\n2000.0" + "\n10";
        System.setIn(new ByteArrayInputStream(data.getBytes()));
        Scanner input = new Scanner(System.in);
        
        boolean expResult = false;
        boolean result = instance.sell(input);
        assertEquals(expResult, result);
    }
    
    
    // Coverage test of buy function when the number of tickets for sale is greater than 100
    // covers all lines of code except the first if-statement
    @Test
    public void testSell5() {
        System.out.println("sell");
        
        System.out.println("buy");
        
        Seller instance = new Seller("sam", 972.0);
        
        String data = "raptorsgame" + "\n20.0" + "\n200";
        System.setIn(new ByteArrayInputStream(data.getBytes()));
        Scanner input = new Scanner(System.in);
        
        boolean expResult = false;
        boolean result = instance.sell(input);
        assertEquals(expResult, result);
    }
}
