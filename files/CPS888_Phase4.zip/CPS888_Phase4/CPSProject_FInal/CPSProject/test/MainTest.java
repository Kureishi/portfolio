import java.util.ArrayList;
import java.util.NoSuchElementException;
import java.util.Scanner;

import static org.junit.Assert.*;

public class MainTest {

    @org.junit.Test
    public void testLogin1() {
        // Statement Coverage Test of Admin user instantiation.
        // Decision Coverage Test for case when for-loop is entered.
        // Decision Coverage Test for case when if-statement checking username is entered.
        // Decision Coverage Test for case when AA if-statement is true.
        // Loop Coverage Test for case when do-while loop is run one time.
        // Loop Coverage Test for case when for-loop is run one time.
        System.out.println("login");
        Main.userAccounts = new InRead("UserAccounts.txt");
        Main.userAccounts.readFile();
        Main.loggedIn = false;
        String input = "Japhet";
        Main.login(new Scanner(input));
        assertTrue(Main.currentUser instanceof Admin);
    }

    @org.junit.Test
    public void testLogin2() {
        // Statement Coverage Test of Buyer user instantiation.
        // Decision Coverage Test for case when AA if-statement is false.
        // Decision Coverage Test for case when BS if-statement is true.
        // Loop Coverage Test for case when for-loop is run two times.
        System.out.println("login");
        Main.userAccounts = new InRead("UserAccounts.txt");
        Main.userAccounts.readFile();
        Main.loggedIn = false;
        String input = "billy";
        Main.login(new Scanner(input));
        assertTrue(Main.currentUser instanceof Buyer);
    }

    @org.junit.Test
    public void testLogin3() {
        // Statement Coverage Test of Seller user instantiation.
        // Decision Coverage Test for case when BS if-statement is false.
        // Decision Coverage Test for case when SS if-statement is true.
        // Loop Coverage Test for case when for-loop is run many times.
        System.out.println("login");
        Main.userAccounts = new InRead("UserAccounts.txt");
        Main.userAccounts.readFile();
        Main.loggedIn = false;
        String input = "bib";
        Main.login(new Scanner(input));
        assertTrue(Main.currentUser instanceof Seller);
    }

    @org.junit.Test(expected = NoSuchElementException.class)
    public void testLogin4() {
        // Statement Coverage Test for case when do-while condition is evaluated.
        // Decision Coverage Test for case when for-loop is not entered.
        // Loop Coverage Test for case when for-loop is run zero times.
        System.out.println("login");
        InRead.uaA = new ArrayList();
        Main.loggedIn = false;
        String input = "foo";
        Main.login(new Scanner(input));
        //Exception is thrown upon login method's attempt to read username the second time.
    }

    @org.junit.Test(expected = NoSuchElementException.class)
    public void testLogin5() {
        // Loop Coverage Test for case when for-loop is run two times.
        // Decision Coverage Test for case when if-statement checking username is not entered.
        System.out.println("login");
        Main.userAccounts = new InRead("UserAccounts.txt");
        Main.userAccounts.readFile();
        Main.loggedIn = false;
        String input = "foo bar";
        Main.login(new Scanner(input));
        //Exception is thrown upon login method's attempt to read username the third time.
    }

    @org.junit.Test(expected = NoSuchElementException.class)
    public void testLogin6() {
        // Loop Coverage Test for case when for-loop is run many times.
        System.out.println("login");
        InRead.uaA = new ArrayList();
        Main.loggedIn = false;
        String input = "foo bar baz";
        Main.login(new Scanner(input));
        //Exception is thrown upon login method's attempt to read username the fourth time.
    }

    @org.junit.Test
    public void testLogin7() {
        // Statement Coverage Test of availableTickets object instantiation and readFile method execution.
        System.out.println("login");
        Main.userAccounts = new InRead("UserAccounts.txt");
        Main.userAccounts.readFile();
        Main.loggedIn = false;
        String input = "billy";
        Main.login(new Scanner(input));
        assertTrue(InRead.atA instanceof ArrayList);
        //ArrayList atA is instantiated once the availableTickets.readFile() line is executed.
    }

    @org.junit.Test
    public void testLogout() {
        // Statement Coverage Test
        System.out.println("logout");
        Main.loggedIn = true;
        Main.logout();
        boolean result = Main.loggedIn;
        assertEquals(false, result);
    }
}