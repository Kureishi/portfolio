
import java.io.ByteArrayInputStream;
import java.util.Scanner;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;


public class BuyerTest {
    
    public BuyerTest() {
    }

    @BeforeClass
    public static void setUpClass() throws Exception {
    }

    @AfterClass
    public static void tearDownClass() throws Exception {
    }

    @Before
    public void setUp() throws Exception {
    }

    @After
    public void tearDown() throws Exception {
    }
    
//    @BeforeClass
//    public static void setUpClass() {
//    }
//    
//    @AfterClass
//    public static void tearDownClass() {
//    }
//    
//    @Before
//    public void setUp() {
//    }
//    
//    @After
//    public void tearDown() {
//    }


    // Coverage test of buy function when all inputs meet constraints and user says 'yes' to purchase
    // covers all lines of code in the first if-statement
   
    @Test
    public void testBuy1() {
        System.out.println("buy");
        
        Buyer instance = new Buyer("billy", 972.0);
        
        String data = "raptorsgame" + "\nsam" + "\n2" + "\nyes";
        System.setIn(new ByteArrayInputStream(data.getBytes()));
        Scanner input = new Scanner(System.in);
        

        boolean expResult = true;
        boolean result = instance.buy(input);
        assertEquals(expResult, result);
    }
    
    // Coverage test of buy function when all inputs meet constraints and user says 'no' to purchase
    // covers all lines of code before the third nested if-statement
    @Test
    public void testBuy2() {
        System.out.println("buy");
        
        Buyer instance = new Buyer("billy", 972.0);
        
        String data = "raptorsgame" + "\nsam" + "\n2" + "\nno";
        System.setIn(new ByteArrayInputStream(data.getBytes()));
        Scanner input = new Scanner(System.in);
        

        boolean expResult = false;
        boolean result = instance.buy(input);
        assertEquals(expResult, result);
    }
    
    // Coverage test of buy function when event title does not exist
    // covers all lines of code except the first if-statement
    
    @Test
    public void testBuy3() {
        System.out.println("buy");
        
        Buyer instance = new Buyer("billy", 972.0);
        
        String data = "fakegame" + "\nsam" + "\n2" + "\nno";
        System.setIn(new ByteArrayInputStream(data.getBytes()));
        Scanner input = new Scanner(System.in);
        

        boolean expResult = false;
        boolean result = instance.buy(input);
        assertEquals(expResult, result);
    }
    

    // Coverage test of buy function when seller does not exist
    // covers all lines of code except the second nested if-statement
    
    @Test
    public void testBuy4() {
        System.out.println("buy");
        
        Buyer instance = new Buyer("billy", 972.0);
        
        String data = "raptorsgame" + "\nfakeseller" + "\n2" + "\nno";
        System.setIn(new ByteArrayInputStream(data.getBytes()));
        Scanner input = new Scanner(System.in);
        

        boolean expResult = false;
        boolean result = instance.buy(input);
        assertEquals(expResult, result);
    }
    
    
    // Coverage test of buy function when number of tickets is greater than 4
    // covers all lines of code except the third nested if-statement
    
    @Test
    public void testBuy5() {
        System.out.println("buy");
        
        Buyer instance = new Buyer("billy", 972.0);
        
        String data = "raptorsgame" + "\nsam" + "\n10" + "\nyes";
        System.setIn(new ByteArrayInputStream(data.getBytes()));
        Scanner input = new Scanner(System.in);
        

        boolean expResult = false;
        boolean result = instance.buy(input);
        assertEquals(expResult, result);
    }
    
    // Coverage test of buy function when the buyer does not have enough funds
    // covers all lines of code except the fifth nested if-statement
    
    @Test
    public void testBuy6() {
        System.out.println("buy");
        
        Buyer instance = new Buyer("tom", 0);
        
        String data = "raptorsgame" + "\ntom" + "\n4" + "\nyes";
        System.setIn(new ByteArrayInputStream(data.getBytes()));
        Scanner input = new Scanner(System.in);
        

        boolean expResult = false;
        boolean result = instance.buy(input);
        assertEquals(expResult, result);
    }
    
}
