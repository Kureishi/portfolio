import java.util.Scanner;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.*;

/**
 *
 * @author Sachin
 */
public class AdminTest {
    
    public AdminTest() {
    }

//    @BeforeClass
//    public static void setUpClass() throws Exception {
//    }
//
//    @AfterClass
//    public static void tearDownClass() throws Exception {
//    }
//
//    @Before
//    public void setUp() throws Exception {
//    }
//
//    @After
//    public void tearDown() throws Exception {
//    }
    

    /**
     * Test of refund method, of class Admin -> Correct input.
     */
    @Test
    public void testRefund() {
        
        // Coverage test of refund function when username of buyer/seller are not current
        // and credit administered is within range. Covers all code except the condition-else statements
        
        System.out.println("refund");
        
        Admin instance = new Admin("Japhet", 34500.0);
        
        String data = "billy" + "\nsam" + "\n50.00";
        System.setIn(new ByteArrayInputStream(data.getBytes()));
        Scanner scan = new Scanner(System.in);
        
        
        boolean expResult = true;
        boolean result = instance.refund(scan);
        assertEquals(expResult, result);
    }
    
    /**
     * Test of refund method, of class Admin -> Incorrect input (not current username).
     */
    @Test
    public void testRefund2() {
        
        // Coverage test of refund function when username of buyer/seller are not current
        // and credit administered is within range. Covers 1st-level nested-conditional-else statement
        
        System.out.println("refund");
        
        Admin instance = new Admin("Japhet", 34500.0);
        
        String data = "abcde" + "\nsam" + "\n50.00";
        System.setIn(new ByteArrayInputStream(data.getBytes()));
        Scanner scan = new Scanner(System.in);
        
        
        boolean expResult = false;
        boolean result = instance.refund(scan);
        assertEquals(expResult, result);
    }
    
    /**
     * Test of refund method, of class Admin -> Incorrect input (not enough funds for seller).
     */
    @Test
    public void testRefund3() {
        
        // Coverage test of refund function when username of buyer/seller are current and credit administered
        // causes seller to go into deficit. Covers 2nd-level nested-conditional-else statement
        
        System.out.println("refund");
        
        Admin instance = new Admin("Japhet", 34500.0);
        
        String data = "bib" + "\nsam" + "\n999.00";
        System.setIn(new ByteArrayInputStream(data.getBytes()));
        Scanner scan = new Scanner(System.in);
        
        
        boolean expResult = false;
        boolean result = instance.refund(scan);
        assertEquals(expResult, result);
    }

    /**
     * Test of addCredit method, of class Admin -> Correct Input.
     */
    @Test
    public void testAddCredit() {
        
        // Coverage test of addCredit function when username is current and credit within range
        // Covers all code except conditional-else statement
     
        System.out.println("addCredit");
        Admin instance = new Admin("Japhet", 34500.0);
        
        String data = "billy" + "\n100.00";
        System.setIn(new ByteArrayInputStream(data.getBytes()));
        Scanner scan = new Scanner(System.in);
        

        
        boolean expResult = true;
        boolean result = instance.addCredit(scan);
        assertEquals(expResult, result);
    }
    
    /**
     * Test of addCredit method, of class Admin -> Incorrect Input (not current name).
     */
    @Test
    public void testAddCredit2() {
        
        // Coverage test of addCredit function when username not current
        // and credit administered is within range. Covers else statement
     
        System.out.println("addCredit");
        Admin instance = new Admin("Japhet", 34500.0);
        
        String data = "abcde" + "\n100.00";
        System.setIn(new ByteArrayInputStream(data.getBytes()));
        Scanner scan = new Scanner(System.in);
        
        boolean expResult = false;
        boolean result = instance.addCredit(scan);
        assertEquals(expResult, result);
    }
    
    /**
     * Test of addCredit method, of class Admin -> Incorrect Input (higher credit).
     */
    @Test
    public void testAddCredit3() {
        
        // Coverage test of addCredit function when username is current
        // and credit administered is not within range. Covers else statement
     
        System.out.println("addCredit");
        Admin instance = new Admin("Japhet", 34500.0);
        
        String data = "billy" + "\n1001.00";
        System.setIn(new ByteArrayInputStream(data.getBytes()));
        Scanner scan = new Scanner(System.in);
        
        boolean expResult = false;
        boolean result = instance.addCredit(scan);
        assertEquals(expResult, result);
    }
    
    /**
     * Test of addCredit method, of class Admin -> Incorrect Input (negative credit).
     */
    @Test
    public void testAddCredit4() {
        
        // Coverage test of addCredit function when username is current
        // and credit administered is not within range (negative). Covers else statement
     
        System.out.println("addCredit");
        Admin instance = new Admin("Japhet", 34500.0);
        
        String data = "billy" + "\n-5.00";
        System.setIn(new ByteArrayInputStream(data.getBytes()));
        Scanner scan = new Scanner(System.in);
        
        boolean expResult = false;
        boolean result = instance.addCredit(scan);
        assertEquals(expResult, result);
    }

    /**
     * Test of delete method, of class Admin.
     */
    @Test
    public void testDelete() {

        //Coverage test of delete function in the case where the user does not exist, covers code up until the catch statement

        System.out.println("delete");
        String username = "ryerson";
        Admin instance = new Admin("Japhet", 34500.0);
        boolean expResult = false;
        boolean result = instance.delete(username);
        assertEquals(expResult, result);
    }
    
    /**
     * Test of delete method, of class Admin.
     */
    @Test
    public void testDelete2() {
        //Coverage test of delete function, in case where user does exist and is deleted correctly, covers all parts of
        //method, aside from catch statement that executes when the user being asked to delete does NOT exist

        System.out.println("delete");
        String username = "mike";
        Admin instance = new Admin("Japhet", 34500.0);
        boolean expResult = true;
        boolean result = instance.delete(username);
        assertEquals(expResult, result);
    }    
    

    /**
     * Test of create method, of class Admin.
     */
    @Test
    public void testCreate() {

        //Coverage test for the create function, assures that each statement in the method runs atleast once,
        //in order for this statement to get full coverage, each time there is an incorrect input, such as too long of a
        //name, the user must then enter a valid input to exit the loop, hence there being multiple inputs for each question
        //when creating a  new user

        System.out.println("create");
        Admin instance = new Admin("Japhet", 34500.0);
        
        String data = "mike" + "\nhbfisdfijsdnfsnbdhfdscd" + "\nsachin" + "\nBB" + "\nBS" + "\n1000000.00" + "\n-5.00" + "\n100.00";
        System.setIn(new ByteArrayInputStream(data.getBytes()));
        Scanner scan = new Scanner(System.in);

        boolean expResult = true;
        boolean result = instance.create(scan);
        assertEquals(expResult, result);
    }
    
}
