/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.ByteArrayInputStream;
import java.util.Scanner;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Sachin
 */
public class UserTest {
    
    public UserTest() {
    }
    

    /**
     * Test of addCredit method, of class User -> Correct Input.
     */
    @Test
    public void testAddCredit() {
        
        // Coverage test of addCredit function when username is current and credit within range
        // Covers all code except conditional-else statement
        
        System.out.println("addCredit");
        
        Buyer instance = new Buyer("bib", 1972.0);
        
        String data = "100.00";
        System.setIn(new ByteArrayInputStream(data.getBytes()));
        Scanner scan = new Scanner(System.in);
        
        boolean expResult = true;
        boolean result = instance.addCredit(scan);
        assertEquals(expResult, result);
    }
    
    /**
     * Test of addCredit method, of class User -> Incorrect Input (higher credit).
     */
    @Test
    public void testAddCredit2() {
        
        // Coverage test of addCredit function when username is current
        // and credit administered is not within range. Covers else statement
        
        System.out.println("addCredit");
        
        Buyer instance = new Buyer("bib", 1972.0);
        
        String data = "1001.00";
        System.setIn(new ByteArrayInputStream(data.getBytes()));
        Scanner scan = new Scanner(System.in);
        
        boolean expResult = false;
        boolean result = instance.addCredit(scan);
        assertEquals(expResult, result);
    }
    
    /**
     * Test of addCredit method, of class User -> Incorrect Input (negative credit).
     */
    @Test
    public void testAddCredit3() {
        
        // Coverage test of addCredit function when username is current
        // and credit administered is not within range (negative). Covers else statement
        
        System.out.println("addCredit");
        
        Buyer instance = new Buyer("bib", 1972.0);
        
        String data = "-5.00";
        System.setIn(new ByteArrayInputStream(data.getBytes()));
        Scanner scan = new Scanner(System.in);
        
        boolean expResult = false;
        boolean result = instance.addCredit(scan);
        assertEquals(expResult, result);
    }
    
}
