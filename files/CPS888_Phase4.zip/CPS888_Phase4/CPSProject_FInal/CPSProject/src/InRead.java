import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

public class InRead {
    
    private Scanner file;  // Scanner can also read from file
    protected static List atA, atB, atC ,atD, uaA, uaB, uaC;  

    String fileName;

    
    public InRead(String fileName) {                                            //file name IS case sensitive
        this.fileName = fileName.trim();
    }
    
    public void openFile() {                                                    // made to public access in order to use file in other classes
        try {
            file = new Scanner (new File(fileName));
        }
        catch(FileNotFoundException e) {
            System.out.println("FILE: '"+ fileName +"' not found");
        }
    }
    
    public void closeFile() {                                                   // made to public access in order to use file in other classes
        file.close(); 
    }

    public void readFile() {
        openFile();
        if(fileName.equals("AvailableTickets.txt")){
            atA = new ArrayList();
            atB = new ArrayList();
            atC = new ArrayList();
            atD = new ArrayList();
            while(file.hasNext()){
                String eventName = file.next();
                if(eventName.equals("END"))
                    break;
                atA.add(eventName);                                             //event name
                atB.add(file.next());                                           //seller's username
                atC.add(Integer.parseInt(file.next()));                         //number of tickets for sale
                atD.add(Double.parseDouble(file.next()));                       //price per ticket
            }
        } else if(fileName.equals("UserAccounts.txt")){
            uaA = new ArrayList();
            uaB = new ArrayList();
            uaC = new ArrayList();
             while(file.hasNext()){
                String userName = file.next();
                if(userName.equals("END"))
                    break;
                uaA.add(userName);//user name
                uaB.add(file.next());//user type
                uaC.add(Double.parseDouble(file.next()));//available credit
            }
        }
        
        closeFile();
    }
    public void writeFile(String transaction){
        try{
            if(fileName.equals("DailyTransactions.txt")){
                
                FileWriter fw = new FileWriter(fileName);
                PrintWriter pw = new PrintWriter(fw, true);
                pw.println(transaction);
                fw.close();
                pw.close();
            }
            
        } catch (IOException ex) {
            Logger.getLogger(InRead.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    public void writeFile() {
        try {
            FileWriter fw = new FileWriter(fileName);
            PrintWriter pw = new PrintWriter(fw);
            
            if(fileName.equals("AvailableTickets.txt")){
                for(int i = 0; i < atA.size(); i++){
                    String eventname = String.format("%1$-19s", atA.get(i));
                    String sellername = String.format("%1$-14s", atB.get(i));
                    String tickets = String.format("%1$-3s", atC.get(i));
                    String price = String.format("%1$-6s", atD.get(i)); //Padding variables 
                    pw.println(eventname + " " + sellername + " " + tickets + " " + price);
                }
            } else if(fileName.equals("UserAccounts.txt")){
                for(int i = 0; i < uaA.size(); i++){
                    
                    String username = String.format("%1$-15s", uaA.get(i));
                    String balance = String.format("%1$-9s", uaC.get(i));
                    pw.println(username + " " + uaB.get(i) + " " + balance);
                    
                }
            }
            
            pw.close();
            fw.close();
        } catch (IOException ex) {
            Logger.getLogger(InRead.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
}
