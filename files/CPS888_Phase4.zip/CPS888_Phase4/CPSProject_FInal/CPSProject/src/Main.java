import java.util.Scanner;

public class Main {
    static InRead userAccounts, availableTickets, dailyTransactions;
    static boolean loggedIn = false;
    static User currentUser;
    
    public static void login (Scanner sc){
        
        do{
            System.out.print("Username: ");
            String username = sc.next().toLowerCase().trim();
            int i;
            for (i = 0; i < InRead.uaA.size(); i++) {
                String tmp = ((String) InRead.uaA.get(i)).toLowerCase().trim();
                if(tmp.equals(username)){
                    System.out.println("Successful.");
                    loggedIn = true;
                    if(InRead.uaB.get(i).equals("AA")){
                        currentUser = new Admin(username, (double) InRead.uaC.get(i));
                        currentUser.privileged = true;
                    } else if(InRead.uaB.get(i).equals("BS")){
                        currentUser = new Buyer(username, (double) InRead.uaC.get(i));
                    } else if(InRead.uaB.get(i).equals("SS")){
                        currentUser = new Seller(username, (double) InRead.uaC.get(i));
                    }
                    break;
                }
            }

        }while(loggedIn == false);
        
        availableTickets = new InRead("AvailableTickets.txt");
        availableTickets.readFile();
    }
    
    public static void logout(){
//        dailyTransactions = new InRead("DailyTransactions.txt");
//        dailyTransactions.writeFile();
        loggedIn = false;
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String token="";
        Scanner scan = new Scanner(System.in);
        userAccounts = new InRead("UserAccounts.txt");
        userAccounts.readFile();
        
        do{
            System.out.print("\nEnter a command: ");
            while(loggedIn == false){
                token = scan.next().toLowerCase().trim();
                if(token.equals("login")){
                    if(loggedIn == false){
                        login(scan);
                    }               
                }
            }

            if(currentUser instanceof Admin){
                do{
                    System.out.print("\nEnter a command (create, delete, addCredit, refund, logout): ");
                    token = scan.next().toLowerCase().trim();
                    switch(token){
                        case "create":
                            if(loggedIn == true){                            
                                ((Admin)currentUser).create(scan);
                                
                                InRead r2 = new InRead("DailyTransactions.txt");
                                String transaction = "01 " + currentUser.username + " AA "+ " " + currentUser.balance; 
                                r2.writeFile(transaction);
                            }
                            break;
                        case "delete":
                            if(loggedIn == true){
                                System.out.println("Enter the username of the user you want to delete (Case sensitive):");
                                String deleteusername = scan.next().trim();
                                
                                if (deleteusername.equals(currentUser.username)){
                                    System.out.println("Cannot delete yourself");
                                }
                                
                                else{
                                     ((Admin)currentUser).delete(deleteusername);
                                }
                                
                                InRead r2 = new InRead("DailyTransactions.txt");
                                String transaction = "02 " + currentUser.username + " AA "+ " " + currentUser.balance; 
                                r2.writeFile(transaction);   
                            }
                            break; 
                        case "addcredit":                                   // token above transforms everything to lowercase
                            if(loggedIn == true){
                                currentUser.addCredit(scan);
                            }
                            break;   
                        case "refund":
                            if(loggedIn == true){
                                ((Admin)currentUser).refund(scan);
                            }
                            break;   
                        case "logout":
                            if(loggedIn == true){
                                logout(); //this makes things work now.
                            }
                            break;
                        case "exit":
                            if(loggedIn == true){
                                logout(); //this makes things work now.
                            }
                            break;

                    }
                }while(!((token.equals("exit")) || (token.equals("logout"))));  
            } else if(currentUser instanceof Buyer){
                do{
                    System.out.print("\nEnter a command (buy, addCredit, logout): ");
                    token = scan.next().toLowerCase().trim();
                    switch(token){
                        case "buy":
                            if(loggedIn == true){
                                ((Buyer)currentUser).buy(scan);
                               System.out.print("\nSystem access restricted, logout and login to regain access."); 
                                logout();
                            }
                            break;  
                        case "addcredit":                                   
                            if(loggedIn == true){
                                currentUser.addCredit(scan);
                            }
                            break;
                        case "logout":
                            if(loggedIn == true){
                                logout();
                            }
                            break;
                        case "exit":
                            if(loggedIn == true){
                                logout(); //this makes things work now.
                            }
                            break;
                    }

                } while(!((token.equals("exit")) || (token.equals("logout"))));
            } else if(currentUser instanceof Seller){
                do{
                    System.out.print("\nEnter a command (sell, addCredit, logout): ");
                    token = scan.next().toLowerCase().trim();
                    switch(token){
                        case "sell":
                            if(loggedIn == true){
                                ((Seller)currentUser).sell(scan);
                                System.out.print("\nSystem access restricted, logout and login to regain access."); 
                                logout();
                            }
                            break;  
                        case "addcredit":                                   
                            if(loggedIn == true){
                                currentUser.addCredit(scan);
                            }
                            break;
                        case "logout":
                            if(loggedIn == true){
                                logout();
                            }
                            break;
                        case "exit":
                            if(loggedIn == true){
                                logout(); //this makes things work now.
                            }
                            break;
                    }

                } while(!((token.equals("exit")) || (token.equals("logout"))));
            }
        }while(!(token.equals("exit")));
    }
    
}
