
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import static java.lang.System.out;
import java.util.Scanner;

/**
 *
 * @author japhet
 */
public class Admin extends User {

    public Admin(String username, double balance) {
        super(username, balance);
    }
    

    public boolean refund (Scanner scan){
        
        double new_credit_buy;                                                  // new credit given applied to buyer and seller
        double new_credit_sell;
        
        System.out.println("Enter buyer username: ");
        String buyer = scan.next();
        
        System.out.println("Enter seller username: ");
        String seller = scan.next();
        
        System.out.println("Enter credit: ");
        Double credit = scan.nextDouble();
        
        InRead rw_account = new InRead("UserAccounts.txt");                     // link to UserAccount file
        rw_account.readFile();

        InRead rw_daily = new InRead("DailyTransactions.txt");                  // link to DailyTransaction file
        
        if (InRead.uaA.contains(buyer) &&  InRead.uaA.contains(seller)) {// check that both buyer and seller are current users
            
            int sell_index = InRead.uaA.indexOf(seller);                    // index of seller and buyer username
            int buy_index = InRead.uaA.indexOf(buyer);
   
            if((double) InRead.uaC.get(sell_index) >= credit) {              // make sure seller have enough funds
                new_credit_sell = (double) InRead.uaC.get(sell_index) - credit;  // subtract specified credit from seller's current credit -> new seller credit
                new_credit_buy = (double) InRead.uaC.get(buy_index) + credit;    // add specified credit to buyer's current credit -> new buyer credit


                InRead.uaC.add(buy_index, new_credit_buy);                     // modify the balance at buyer username to new buyer credit
                InRead.uaC.add(sell_index, new_credit_sell);

                rw_account.writeFile();                                             // write the modifications to the user accounts file

                String buyer_print = String.format("%1$-15s", buyer);
                String seller_print = String.format("%1$-15s", seller);
                String new_credit_print = String.format("%1$-9s", credit);

                rw_daily.writeFile("05 " + buyer_print + " " + seller_print + " " + new_credit_print);

                System.out.println("Refund Successful");

                return true;
            }
            else {
                System.out.println("Not enough funds available in Seller's account");   // display if not enough funds
                return false;
            }
            
        }
        else {
            System.out.println("Buyer username or Seller username is not in current account list");     // return error if not in current user accounts list
            return false;
        }
    }

    @Override
    public boolean addCredit(Scanner scan){
        
        System.out.println("Enter username to apply credit to: ");
        String username = scan.next();
        
        System.out.println("Enter credit: ");
        Double credit = scan.nextDouble();
        
        double newCredit;
        
        InRead rw_account = new InRead("UserAccounts.txt");
        rw_account.readFile();
        
        InRead rw_daily = new InRead("DailyTransactions.txt");
        
        if (InRead.uaA.contains(username) && ((credit >= 0.00) && (credit < 1000.00))) {            // checks that username is current and credit applied is less than $1000.00
            int i = InRead.uaA.indexOf(username);                           // index of specified username in user account file

            newCredit = (double) InRead.uaC.get(i) + credit;                 // add specified credit to user's current credit -> new buyer credit

            InRead.uaC.add(i, newCredit);                                   // modify the balance at user's username to new their new balance/credit
            rw_account.writeFile();                                             // write the modifications to the user accounts file

            String username_print = String.format("%1$-15s", username);         // pad the username for 15 characters in accordance with daily file
            String new_credit_print = String.format("%1$-9s", newCredit);          // pad the credit for 9 characters in accordance with daily file
            
            rw_daily.writeFile("06 " + username_print + " " + InRead.uaB.get(i) + " " + new_credit_print); // write modification of user to daily transaction file
            
            System.out.println("Credit successful");

            return true;
        }
        else {
            System.out.println("Username is not in current account list or credit applied exceeds range");       // if not, display error message on console
            return false;
        }
    }

    //Deletes specified username, is case sensitive, admin privileged transaction
    public boolean delete (String username){

        int i = 0; 
        String lineToRemove;
        InRead r = new InRead("UserAccounts.txt");
        
        r.readFile();
        r.writeFile();
        
         try {
            
             i = InRead.uaA.indexOf(username);
             lineToRemove = InRead.uaA.get(i) + " " + InRead.uaB.get(i) + " " + InRead.uaC.get(i);
             InRead.uaA.remove(i);
             InRead.uaB.remove(i);
             InRead.uaC.remove(i);
        
            
        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("User does not exist");
            return false;
        }
        
         r.writeFile();
        
        System.out.println("Delete successful.");
        
        return true;
    }
    
    
    //Creates specified user, requires user does not alread exist, admin priveleged transaction
    public boolean create (Scanner scan){
        
        InRead r = new InRead("UserAccounts.txt");
        
        String user;
        String type;
        double balance2;
                
        r.readFile();
        r.writeFile();
        
        while(true){
            System.out.println("Enter the username:");
            user = scan.next().trim();
            
            if (InRead.uaA.contains(user)){
                System.out.println("Username taken");
            } else if (user.length() > 15){
                System.out.println("Username too long");
            } else {
                break; 
            }
            
        }
        
        while(true){
            System.out.println("Enter the User type:");
            type = scan.next().trim();
            
            if ((!type.equals("SS"))&&(!type.equals("AA")) && (!type.equals("BS"))){
                System.out.println("Invalid type");
            } else {
                break; 
            }
            
        }
        
        while(true){
            System.out.println("Enter balance:");
            balance2 = scan.nextDouble();
            
            if (balance2 > 999999 || balance2 < 0){
                System.out.println("Invalid balance");
            } else {
                break; 
            }
            
        }
        
        InRead.uaA.add(user);
        InRead.uaB.add(type);
        InRead.uaC.add(balance2);
        
        r.writeFile();
        r.readFile();
        
        System.out.println("Create successful.");

        return true;
    }
}
