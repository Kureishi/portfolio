
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;
//

public class Buyer extends User {

    public Buyer(String username, double balance) {
        super(username, balance);
    }


    public boolean buy(Scanner input) {

        InRead userAccount = new InRead("UserAccounts.txt");                     // link to UserAccount file
        userAccount.readFile();

        InRead availTickets = new InRead("AvailableTickets.txt");                     // link to AvailableTickets file
        availTickets.readFile();

        InRead dailyTrans = new InRead("DailyTransactions.txt");                  // link to DailyTransaction file

        int newTickets;
        double totalPrice;
        double newSellerBalance;
        double newBuyerBalance;

        String type = "04 ";

        System.out.print("\nWhat event would you like to buy tickets for?  ");
        String eventTitle = input.next();
        System.out.print("\nWhat is the name of the seller? ");
        String sellerUsername = input.next();
        System.out.print("\nHow many tickets would you like to buy?  ");
        int numTickets = input.nextInt();

        for (int i = 0; i < InRead.atB.size(); i++) {
            String tmptic = ((String) InRead.atA.get(i)).toLowerCase().trim();

            if (tmptic.equals(eventTitle)) {
                String tmpname = ((String) InRead.atB.get(i)).toLowerCase().trim();

                if (tmpname.equals(sellerUsername)) {
                    totalPrice = numTickets * ((Double) InRead.atD.get(i));
                    System.out.print("\n" + sellerUsername + " is offering " + (InRead.atC.get(i)) + " for " + (InRead.atD.get(i)) + " each ");
                    System.out.print("\nWould you like to buy " + numTickets + " for a total of $ " + totalPrice);
                    System.out.print("\nYes or No? ");
                    String answer = input.next();

                    if (answer.equalsIgnoreCase("yes")) {
                        if (numTickets <= ((int) InRead.atC.get(i)) && (numTickets > 0) && (numTickets <= 4)) {
                            if ((((Double) InRead.uaC.get(InRead.uaA.indexOf(sellerUsername))) - totalPrice) > 0) {
                                int sellerIndex = InRead.uaA.indexOf(sellerUsername);
                                int buyerIndex = InRead.uaA.indexOf(username);

                                newTickets = (int) InRead.atC.get(i) - numTickets;
                                InRead.atC.add(i, newTickets);

                                newSellerBalance = (double) InRead.uaC.get(sellerIndex) + totalPrice;
                                InRead.uaC.add(sellerIndex, newSellerBalance);

                                newBuyerBalance = (double) InRead.uaC.get(buyerIndex) - totalPrice;
                                InRead.uaC.add(buyerIndex, newBuyerBalance);

                                availTickets.writeFile();
                                userAccount.writeFile();

                                String eventTitlePrint = String.format("%1$-19s", eventTitle);   // padding
                                String usernamePrint = String.format("%1$-13s", username);
                                String numTicketsPrint = String.format("%1$-3s", numTickets);
                                String totalPricePrint = String.format("%1$-6s", totalPrice);

                                dailyTrans.writeFile(type + " " + eventTitlePrint + " " + usernamePrint + " " + numTicketsPrint + " " + totalPricePrint);

                                System.out.println("\nTicket purchase successful.");

                                if ((int) InRead.atC.get(i) == 0) {
//                                    String lineToRemove = "";
//                                    lineToRemove = InRead.atA.get(i) + " " + InRead.atB.get(i) + " " + InRead.atC.get(i) + " " + InRead.atD.get(i);
                                    InRead.atA.remove(i);
                                    InRead.atB.remove(i);
                                    InRead.atC.remove(i);
                                    availTickets.writeFile();
                                    return true;
                                }
                                return true;
                            }
                            System.out.print("\nNo tickets were purchased, not enough funds.");
                            return false;
                        }
                        System.out.print("\nNo tickets were purchased, constraints not met.");
                        return false;
                    } else if (answer.equalsIgnoreCase("no")) {
                        System.out.print("\nNo tickets were purchased.");
                        return false;
                    }
                }
                System.out.print("\nSeller does not exist.");
                return false;
            }
        }
        System.out.print("\nEvent does not exist. ");
        return false;
    }

}