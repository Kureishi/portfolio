import java.util.Scanner;


public class Seller extends User {

    public Seller(String username, double balance) {
        super(username, balance);

    }

    public boolean sell(Scanner input) {
        String type = "03 ";

        InRead availTickets = new InRead("AvailableTickets.txt");                     // link to AvailableTickets file
        availTickets.readFile();

        InRead dailyTrans = new InRead("DailyTransactions.txt");                  // link to DailyTransaction file

        System.out.print("\nWhat event would you like to sell tickets for?  ");
        String eventTitle = input.next();
        int length = eventTitle.length();

        System.out.print("\nWhat price would you like to sell tickets for?  ");
        double price = input.nextDouble();

        System.out.print("\nHow many tickets would you like to sell?    ");
        int numTickets = input.nextInt();

        if ((length <= 25 && length > 0) && (price > 0 && price < 1000) && (numTickets > 0 && numTickets <= 100)) {

            for (int i = 0; i < InRead.atB.size(); i++) {
                String tmptic = ((String) InRead.atA.get(i)).toLowerCase().trim();
                if (tmptic.equals(eventTitle)) {
                    String tmpname = ((String) InRead.atB.get(i)).toLowerCase().trim();
                    if (tmpname.equals(username)) {
                        Double tmpprice = ((double) InRead.atD.get(i));
                        if (tmpprice.equals(price)){
                            int newTickets = (int) InRead.atC.get(i) + numTickets;
                            InRead.atC.add(i, newTickets);

                            availTickets.writeFile();
                            System.out.println("Ticket sale successful\n"); //should say "New tickets added successfully"
                            return true;
                        }
                    }

                } else {
                    InRead.atA.add(eventTitle);
                    InRead.atB.add(username);
                    InRead.atC.add(numTickets);
                    InRead.atD.add(price);
                    availTickets.writeFile();

                    String eventTitlePrint = String.format("%1$-19s", eventTitle);   // padding
                    String usernamePrint = String.format("%1$-13s", username);
                    String numTicketsPrint = String.format("%1$-3s", numTickets);
                    String PricePrint = String.format("%1$-6s", price);

                    dailyTrans.writeFile(type + " " + eventTitlePrint + " " + usernamePrint + " " + numTicketsPrint + " " + PricePrint);
                    System.out.println("Ticket sale successful\n");

                    return true;
                }
            }
            if (InRead.atB.size() == 0) {
                InRead.atA.add(eventTitle);
                InRead.atB.add(username);
                InRead.atC.add(numTickets);
                InRead.atD.add(price);
                availTickets.writeFile();

                dailyTrans.writeFile(type + " " + eventTitle + " " + username + " " + numTickets + " " + price);
                System.out.println("Ticket sale successful\n");

                return true;
            }
        }
        System.out.println("\nTicket sale unsuccessful, constraints not met"); //should say "Adding tickets unsuccessful"
        return false;
    }
}