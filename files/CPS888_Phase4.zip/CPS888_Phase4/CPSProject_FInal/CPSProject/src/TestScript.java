
import java.io.*;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


public class TestScript {


    public static void main(String[] argz) throws IOException{
        System.out.println("main");

        String[] args = null;
        PrintStream original=System.out; // save
        FileInputStream fips;
        FileOutputStream fops;
        File expectedOutput, actualOutput;
        //System.out.println(Paths.get(".").toAbsolutePath().normalize().toString());
        File testSuiteDir = new File("./TestSuite");
        File[] testSuiteDirListing = testSuiteDir.listFiles(file -> !file.isHidden());
        if(testSuiteDirListing != null){
            for(File transactionDir : testSuiteDirListing){
                File[] transactionDirListing = transactionDir.listFiles(file -> !file.isHidden());
                for(File testCaseDir : transactionDirListing){
                    File[] matchingInputFile = testCaseDir.listFiles((dir, name) -> name.startsWith("input") && name.endsWith("txt"));
                    File[] matchingOutputFile = testCaseDir.listFiles((dir, name) -> name.startsWith("output") && name.endsWith("txt"));

                    fips = new FileInputStream(matchingInputFile[0]);
                    System.setIn(fips);
                    expectedOutput = matchingOutputFile[0];
                    actualOutput = new File(expectedOutput.getParent() + "/actualOutput.txt");
                    actualOutput.createNewFile();
                    fops = new FileOutputStream(actualOutput);
                    System.setOut(new PrintStream(fops));

                    Main.main(args); //run main for every test case
                    byte[] f1 = Files.readAllBytes(expectedOutput.toPath());
                    byte[] f2 = Files.readAllBytes(actualOutput.toPath());

                    BufferedReader br1 = null;
                    BufferedReader br2 = null;
                    String sCurrentLine;
                    List<String> list1 = new ArrayList<String>();
                    List<String> list2 = new ArrayList<String>();
                    br1 = new BufferedReader(new FileReader(expectedOutput));
                    br2 = new BufferedReader(new FileReader(actualOutput));
                    while ((sCurrentLine = br1.readLine()) != null) {
                        list1.add(sCurrentLine);
                    }
                    while ((sCurrentLine = br2.readLine()) != null) {
                        list2.add(sCurrentLine);
                    }

                    System.setOut(original);
                    if(list1.equals(list2)){
                        System.out.println(transactionDir.getName() + ": "
                                + testCaseDir.getName()+": pass");
                    } else {
                        System.out.println(transactionDir.getName() + ": "
                                + testCaseDir.getName()+": fail");
                    }
                }
            }
        }

        System.setIn(System.in);
        System.setOut(System.out);
    }
}
