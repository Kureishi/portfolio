import java.util.Scanner;


public class User {

    String username;
    double balance;
    boolean privileged;

    public User(String username, double balance) {
        this.username = username;
        this.balance = balance;
    }


    public boolean addCredit(Scanner scan) {

        double newCredit;
        
        System.out.println("Enter credit: ");
        Double credit = scan.nextDouble();

        InRead rw_account = new InRead("UserAccounts.txt");
        rw_account.readFile();

        InRead rw_daily = new InRead("DailyTransactions.txt");

        if (InRead.uaA.contains(username) && ((credit >= 0.00) && (credit < 1000.00))) {            // checks that user's own username is current and credit applied is less than $1000.00
            int i = InRead.uaA.indexOf(username);                           // index of specified username in user account file

            newCredit = (double) InRead.uaC.get(i) + credit;                 // add specified credit to user's current credit -> new buyer credit

            InRead.uaC.add(i, newCredit);                                   // modify the balance at user's username to new their new balance/credit
            rw_account.writeFile();                                             // write the modifications to the user accounts file

            String username_print = String.format("%1$-15s", username);         // pad the username for 15 characters in accordance with daily file
            String new_credit_print = String.format("%1$-9s", newCredit);          // pad the credit for 9 characters in accordance with daily file

            rw_daily.writeFile("06 " + username_print + " " + InRead.uaB.get(i) + " " + new_credit_print); // write modification of user to daily transaction file

            System.out.println("Credit successful");

            return true;
        } else {
            System.out.println("Username is not in current account list or credit applied exceeds range");       // if not, display error message on console
            return false;
        }
    }
}
